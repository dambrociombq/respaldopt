﻿using sacot.Data.ClientsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class MidocumentoBLL
    { 
        public List<Documento> ObtenerDocumentos(int iduser)
        {
            MidocumentoData documentodata = new MidocumentoData();
            return documentodata.ObtenerDocumentos(iduser);
        }
        public Documento ObtenerDocumentoPorId(int idDocumento)
        {
            // Lógica para obtener el documento desde la base de datos
            MidocumentoData documentoData = new MidocumentoData(); // Instancia de la clase Data para acceso a datos
            return documentoData.ObtenerDocumentoPorId(idDocumento);
        }
    }
}