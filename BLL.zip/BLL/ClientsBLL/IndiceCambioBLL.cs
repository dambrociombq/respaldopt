﻿using sacot.Data.ClientsData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class IndiceCambioBLL
    {
        private IndiceCambioData _indiceCambioData;

        public IndiceCambioBLL()
        {
            _indiceCambioData = new IndiceCambioData();
        }

        public void RegistrarCambio(int documentoID, string descripcionParrafo, string refParrafo, string refPagina)
        { 
            DateTime fecha = DateTime.Now;
            _indiceCambioData.InsertarCambio(documentoID, fecha, descripcionParrafo, refParrafo, refPagina);
        }
    }
}