﻿using sacot.Data.AdministratorsData;
using sacot.Data.ClientsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class MenuBLL
    {
        // Instancia de la capa de datos para interactuar con la base de datos
        private MenuData menuData = new MenuData();

        // Método para obtener el usuario y su rol
        public Usuarios ObtenerUsuarioYRole(int idUsuario)
        {
            try
            {
                // Invoca el método de la capa de datos para obtener los datos del usuario y su rol
                return menuData.ObtenerUsuarioYRole(idUsuario);
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                Console.WriteLine("Error en MenuAdmiBLL: " + ex.Message);
                throw; // Re-lanza la excepción para que sea manejada en la capa de presentación
            }
        }
    }
}