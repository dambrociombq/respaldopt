﻿using sacot.Data.ClientsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class AutorizacionBLL
    {
        //metodo para insertar pie de pagina
        public int InsertarDatos(Autorizaciones autorizacion)
        {
            // Crear una instancia de la clase de acceso a datos (DAL)
            AutorizacionData autorizacionData = new AutorizacionData();

            // Llamar al método de inserción en la capa de acceso a datos
            return autorizacionData.InsertarDatos(autorizacion);
        }

        // Método para editar el documento con los datos de autorización
        public bool EditarDocAutorizo(int idDocumento, int idAutorizaciones)
        {
            // Crear una instancia de la clase de acceso a datos (DAL)
            AutorizacionData autorizacionData = new AutorizacionData();

            // Llamar al método de actualización en la capa de acceso a datos
            return autorizacionData.EditarDocAutorizo(idDocumento, idAutorizaciones);
        }
    }
}