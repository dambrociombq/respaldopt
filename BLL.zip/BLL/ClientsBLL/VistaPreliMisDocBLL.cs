﻿using sacot.Data.ClientsData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class VistaPreliMisDocBLL
    {
        public static byte[] ObtenerPDFBytes(int iddocumento)
        {
            // Llamar a la capa de acceso a datos para obtener los datos binarios del PDF
            return VistaPreliMisDocData.ObtenerPDFBytes(iddocumento);
        }
    }
}