﻿using sacot.Data.ClientsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class EncabePieBLL
    {
        // Método para insertar los datos del encabezado
        public int InsertarDatosEncabezado(DocumentoEncabezado encabezado)
        {
            EncabePieData encabePieData = new EncabePieData();
            return encabePieData.InsertarEncabezado(encabezado);
        }

        // Método para insertar los datos del pie de página
        public int InsertarDatosPiePagina(DocumentoPiePagina piePagina)
        {
            EncabePieData encabePieData = new EncabePieData();
            return encabePieData.InsertarPiePagina(piePagina);
        }

        // Método para editar el documento con los datos del encabezado y pie de página
        public bool EditarDocumento(int idDocumento, int idEncabezado, int idPiePagina)
        {
            EncabePieData encabePieData = new EncabePieData();
            return encabePieData.EditarDocumento(idDocumento, idEncabezado, idPiePagina);
        }
    }
}