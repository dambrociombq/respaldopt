﻿using sacot.Data.ClientsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class PlantGenericaBLL
    {
        private PlantGenericaData plantillaDAL = new PlantGenericaData();

        public List<PlantillaTemas> ObtenerTemasPorIdPlantilla(int idPlantilla)
        {
            return plantillaDAL.ObtenerTemasPorIdPlantilla(idPlantilla);
        }

        public List<PlantillaSubtemas> ObtenerSubtemasPorIdTema(int idPlantillaTema)
        {
            return plantillaDAL.ObtenerSubtemasPorIdTema(idPlantillaTema);
        }
        public void InsertarDocumentoSubtema(DocumentoSubtema documentoSubtema)
        {
            PlantGenericaData plantGenericaData = new PlantGenericaData();
            plantGenericaData.InsertarDocumentoSubtema(documentoSubtema);
        }
        public int InsertarDocumentoTema(DocumentoTema documentoTema)
        {
            PlantGenericaData plantGenericaData = new PlantGenericaData();
            return plantGenericaData.InsertarDocumentoTema(documentoTema);
        }

    }
}