﻿using sacot.Data.ClientsData;
using sacot.Model;
using sacot.Presentation.Clients;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class GeneracionPDFBLL
    {
        private GeneracionPDFData generacionPDFData = new GeneracionPDFData();

        public Documento ObtenerDocumentoPorId(int idDocumento)
        {
            return generacionPDFData.BuscarDocumentoPorId(idDocumento);
        }

        public DocumentoPortada ObtenerDocumentoPortadaPorId(int idDocumentoPortada)
        {
            return generacionPDFData.BuscarDocumentoPortadaPorId(idDocumentoPortada);
        }

        public DocumentoEncabezado ObtenerDocumentoEncabezadoPorId(int idDocumentoEncabezado)
        {
            return generacionPDFData.BuscarDocumentoEncabezadoPorId(idDocumentoEncabezado);
        }

        public DocumentoPiePagina ObtenerDocumentoPiePaginaPorId(int idDocumentoPiePagina)
        {
            return generacionPDFData.BuscarDocumentoPiePaginaPorId(idDocumentoPiePagina);
        }

        public Autorizaciones ObtenerAutorizacionPorId(int idAutorizacion)
        {
            return generacionPDFData.BuscarAutorizacionPorId(idAutorizacion);
        }

        public List<HistorialCambioDocumento> ObtenerHistorialCambioDocumentoPorId(int DocumentoID)
        {
            return generacionPDFData.ObtenerHistorialCambiosDocumentoPorId(DocumentoID);
        }

        public List<DocumentoTema> ObtenerDocumentoTemasPorId(int idDocumento)
        {
            return generacionPDFData.ObtenerDocumentoTemaPorId(idDocumento);
        }

        public List<DocumentoSubtema> ObtenerDocumentoSubtemasPorId(int documentotemaID)
        {
            return generacionPDFData.ObtenerDocumentoSubtemaPorId(documentotemaID);
        }
        public InformacionDocumento ObtenerInformacionDocumentoPorId(int informacionDocumentoID)
        {
            return generacionPDFData.ObtenerInformacionDocumentoPorId(informacionDocumentoID);
        }
        public void  ActualizarArchivoPDF(int idDocumento, byte[] archivoPDF)
        {
            generacionPDFData.ActualizarArchivoPDF(idDocumento, archivoPDF);
        }
    }
}