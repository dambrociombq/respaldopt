﻿using sacot.Data.ClientsData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class VistaPriliPlantillasBLL
    {
        public static string ObtenerPDFPath(int plantillaId)
        {
            // Llamar a la capa de acceso a datos para obtener el pdfPath correspondiente al ID de la plantilla
            return VistaPriliPlantillasData.ObtenerPDFPath(plantillaId);
        }
    }
}