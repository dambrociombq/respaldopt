﻿using sacot.Data.ClientsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class InformacionDocumentoBLL
    {
        private readonly InformacionDocumentoData informacionDocumentoData;

        public InformacionDocumentoBLL()
        {
            informacionDocumentoData = new InformacionDocumentoData();
        }

        public void InsertarInformacionDocumento(InformacionDocumento informacionDocumento)
        {
            // Aquí puedes implementar lógica adicional antes de insertar en la base de datos
            informacionDocumentoData.InsertarInformacionDocumento(informacionDocumento);
        }
    }
}