﻿using sacot.Data.ClientsData;
using sacot.Model;
using sacot.Presentation.Clients;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class PortadaBLL
    {
        public static int InsertarDatosConLogo(DocumentoPortada portada)
        {
            try
            {
                // Llamar al método en la capa de acceso a datos para insertar los datos en la base de datos
                return PortadaData.InsertarDatosConLogo(portada);
            }
            catch (Exception ex)
            {
                // Manejar cualquier excepción e imprimir un mensaje de error
                Console.WriteLine("Error al insertar los datos de la portada: " + ex.Message);
                return -1;
            }
        }

        public static int InsertarDocumentoConPortada(int idPortada, int idPlantilla, string Titulo,int idusuario)
        {
            try
            {
                // Llamar al método en la capa de acceso a datos para insertar el documento con el ID de la portada y el ID de la plantilla
                return PortadaData.InsertarDocumentoConPortada(idPortada, idPlantilla, Titulo, idusuario);
            }
            catch (Exception ex)
            {
                // Manejar cualquier excepción e imprimir un mensaje de error
                Console.WriteLine("Error al insertar el documento con la portada: " + ex.Message);
                return -1;
            }
        }
    }
}