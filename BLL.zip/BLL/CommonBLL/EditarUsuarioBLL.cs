﻿using sacot.Data.ClientsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.ClientsBLL
{
    public class EditarUsuarioBLL
    {
        private EditarUsuarioData _EditarUsuarioData;

        public EditarUsuarioBLL()
        {
            _EditarUsuarioData = new EditarUsuarioData();
        }

        // Método para obtener un usuario por su ID
        public Usuarios ObtenerUsuarioPorID(int IDUsuario)
        {
            return _EditarUsuarioData.ObtenerUsuarioPorID(IDUsuario);
        }

        // Método para actualizar la contraseña de un usuario
        public bool ActualizarContraseña(int IDUsuario, string nuevaContraseña)
        {
            // Realizar validaciones adicionales si es necesario
            return _EditarUsuarioData.ActualizarContraseña(IDUsuario, nuevaContraseña);
        }
    }
}