﻿using sacot.Data.Common;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.CommonBLL
{
    public class LoginBLL
    {
        private LoginData usuariodata = new LoginData();

        public Usuarios AutenticarUsuario(string email, string contrasena)
        {
            Usuarios usuarios = usuariodata.ObtenerUsuarioPorEmail(email, contrasena);
            if (usuarios != null && usuarios.Contrasena == contrasena)
            {
                return usuarios;
            }
            return null;
        }
    }
}