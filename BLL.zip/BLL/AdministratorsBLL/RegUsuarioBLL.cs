﻿using sacot.Data.AdministratorsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.AdministratorsBLL
{
    public class RegUsuarioBLL
    {
        private RegUsuarioData regUsuarioData;

        public RegUsuarioBLL()
        {
            regUsuarioData = new RegUsuarioData();
        }

        // Método para registrar un nuevo usuario
        public string RegistrarUsuario(Usuarios usuario)
        {
            try
            {
                // Verificar si el usuario ya existe en la base de datos
                bool existeUsuario = regUsuarioData.ExisteUsuario(usuario.NombreUsuario, usuario.CorreoElectronico);
                if (existeUsuario)
                {
                    return "Error: El usuario ya existe en la base de datos.";
                }
                else
                {
                    // Insertar el usuario en la base de datos
                    regUsuarioData.InsertarUsuario(usuario);
                    return "Usuario registrado correctamente.";
                }
            }
            catch (Exception ex)
            {
                return "Ocurrió un error durante el registro de usuario. Por favor, inténtelo de nuevo más tarde.";
            }
        }
    }
}