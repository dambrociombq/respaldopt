﻿using sacot.Data.AdministratorsData;
using sacot.Model;
using System;
namespace sacot.BLL.AdministratorsBLL
{
    public class ActualizarUsuarioBLL
    {
        public Usuarios ObtenerUsuarioPorID(int IDUsuario)
        {
            ActualizarUsuarioData actualizarUsuarioData = new ActualizarUsuarioData();
            return actualizarUsuarioData.ObtenerUsuarioPorID(IDUsuario);
        }

        public string ActualizarUsuario(Usuarios usuario)
        {
            ActualizarUsuarioData actualizarUsuarioData = new ActualizarUsuarioData();

            // Verificar si el nombre de usuario ya existe
            if (actualizarUsuarioData.BuscarExistenciaUsuario(usuario.NombreUsuario, usuario.IDUsuario))
            {
                return "El nombre de usuario ya existe en la base de datos. Intenta con otro.";
            }
            // Verificar si el correo electrónico ya existe
            else if (actualizarUsuarioData.BuscarExistenciaCorreo(usuario.CorreoElectronico, usuario.IDUsuario))
            {
                return "El correo electrónico ya existe en la base de datos. Intenta con otro.";
            }
            else
            {
                // Actualizar el usuario en la base de datos
                actualizarUsuarioData.ActualizarUsuario(usuario);
                return "Usuario actualizado correctamente.";
            }
        }
    }
}
