﻿using sacot.Data.AdministratorsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.AdministratorsBLL
{
    public class ListaUserBLL
    {
        private ListaUserData usuarioDAL = new ListaUserData();  
        public List<Usuarios> ObtenerUsuarios()
        {
            try
            {
                return usuarioDAL.ObtenerUsuarios();
            }
            catch (Exception ex)
            {
                // Aquí podrías manejar errores, registrarlos, lanzar excepciones personalizadas, etc.
                throw new Exception("Error al obtener la lista de usuarios", ex);
            }
        } 
    }
}