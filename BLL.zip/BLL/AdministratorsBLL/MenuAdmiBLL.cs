﻿using sacot.Data.AdministratorsData;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sacot.BLL.AdministratorsBLL
{
    public class MenuAdmiBLL
    {
        // Instancia de la capa de datos para interactuar con la base de datos
        private MenuAdmiData menuAdmiData = new MenuAdmiData();

        // Método para obtener el usuario y su rol
        public Usuarios ObtenerUsuarioYRole(int idUsuario)
        {
            try
            {
                // Invoca el método de la capa de datos para obtener los datos del usuario y su rol
                return menuAdmiData.ObtenerUsuarioYRole(idUsuario);
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                Console.WriteLine("Error en MenuAdmiBLL: " + ex.Message);
                throw; // Re-lanza la excepción para que sea manejada en la capa de presentación
            }
        }
    }
}