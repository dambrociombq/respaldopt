﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using sacot.BLL.CommonBLL;
namespace sacot.Presentation.Common
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Remove("IDUser");
            lblError.Visible = false;
        }
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string contrasena = txtPassword.Text;

            LoginBLL usuarioBLL = new LoginBLL();
            Usuarios usuario = usuarioBLL.AutenticarUsuario(email, contrasena);

            if (usuario != null)
            {
                if (usuario.Estado == "Activo")
                {
                    lblError.Text = "Error. Usuario y/o contraseña incorrecta!";
                    lblError.Visible = false;
                    //variable de sesion
                    Session["IDUser"] = usuario.IDUsuario;
                    // Autenticación exitosa, redirigir según el rol
                    if (usuario.IDRole == 1)
                    {
                        Response.Redirect("../Administrators/RegistroUser.aspx");
                    }
                    else if (usuario.IDRole == 2)
                    {
                        Response.Redirect("../Clients/MisDocumentos.aspx");
                    }
                }
                else
                {
                    // El usuario está inactivo
                    lblError.Visible = true;
                    lblError.Text = "Tu cuenta está inactiva. Por favor, contacta al administrador.";
                }
            }
            else
            {
                // Autenticación fallida
                lblError.Text = "Error. Usuario y/o contraseña incorrecta!";
                lblError.Visible = true;
            }
        }

    }
}