﻿using sacot.BLL.AdministratorsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Administrators
{
    public partial class ListaUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    GridViewListUser.DataSource = null;
                    GridViewListUser.DataBind();
                    CargarUsuarios();
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
                
            }
        }

        private void CargarUsuarios()
        {
            try
            {
                ListaUserBLL usuarioBLL = new ListaUserBLL();
                List<Usuarios> usuarios = usuarioBLL.ObtenerUsuarios();
                GridViewListUser.DataSource = usuarios;
                GridViewListUser.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write($"Ocurrió un error: {ex.Message}");
            }
        }
        protected void GridViewListUser_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Editar")
            {
                // Obtener el índice de la fila seleccionada
                int index = Convert.ToInt32(e.CommandArgument);

                // Obtener el IDUsuario de la fila seleccionada
                string idUsuario = GridViewListUser.DataKeys[index].Values["IDUsuario"].ToString();

                // Redirigir a la otra página de WebForm pasando el IDUsuario como parámetro
                Response.Redirect("ActualizarUsuario.aspx?Usuario=" + idUsuario);
            }
        }
    }
}
