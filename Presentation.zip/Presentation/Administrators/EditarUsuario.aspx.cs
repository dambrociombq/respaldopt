﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Administrators
{
    public partial class EditarUsuario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    Lberror.Visible = false;
                    int IDUsuario = Convert.ToInt16(Session["IDUser"]);
                    if (IDUsuario != 0)
                    {
                        EditarUsuarioBLL editarUsuarioBLL = new EditarUsuarioBLL();
                        Usuarios usuario = editarUsuarioBLL.ObtenerUsuarioPorID(IDUsuario);
                        if (usuario != null)
                        {
                            lblNombre.Text = usuario.Nombre;
                            lblApellido.Text = usuario.Apellido;
                            lblCorreo.Text = usuario.CorreoElectronico;
                        }
                    }
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }

            }
        }

        protected void Btncambiarpassword_Click(object sender, EventArgs e)
        {
            int IDUsuario = Convert.ToInt16(Session["IDUser"]);
            string contraseñaAnterior = txtContrasenaAnterior.Value; // Obtenemos el valor del campo de contraseña anterior
            string nuevaContraseña = txtNuevaContrasena.Value; // Obtenemos el valor del campo de nueva contraseña
            string confirmarContraseña = txtConfirmarContrasena.Value; // Obtenemos el valor del campo de confirmar contraseña

            // Validar la contraseña
            if (!ValidarContrasena(nuevaContraseña))
            {
                // Mostrar mensaje de error de contraseña no válida
                MostrarMensaje("Error: La contraseña debe tener al menos 8 caracteres, incluyendo al menos un número, letras mayusculas, letras minusculas y un carácter especial.", true);
                return; // Salir del método ya que la contraseña no es válida
            }

            if (contraseñaAnterior != "" && nuevaContraseña != "" && confirmarContraseña != "")
            {
                // Verificar si la contraseña anterior coincide con la de la base de datos
                EditarUsuarioBLL EditarUsuarioBLL = new EditarUsuarioBLL();
                Usuarios usuario = EditarUsuarioBLL.ObtenerUsuarioPorID(IDUsuario);
                if (usuario != null && usuario.Contrasena == contraseñaAnterior)
                {
                    if (nuevaContraseña == confirmarContraseña)
                    {
                        bool contraseñaActualizada = EditarUsuarioBLL.ActualizarContraseña(IDUsuario, nuevaContraseña);
                        if (contraseñaActualizada)
                        {
                            // La contraseña se actualizó correctamente
                            // Puedes mostrar un mensaje de éxito o redireccionar a otra página
                            MostrarMensaje("La contraseña se actualizó correctamente", false);
                        }
                        else
                        {
                            // Ocurrió un error al actualizar la contraseña
                            // Puedes mostrar un mensaje de error o manejar la situación según tu caso
                            MostrarMensaje("Ocurrió un error al actualizar la contraseña", true);
                        }
                    }
                    else
                    {
                        // La nueva contraseña y la confirmación no coinciden
                        MostrarMensaje("La nueva contraseña y la confirmación no coinciden", true);
                    }
                }
                else
                {
                    // La contraseña anterior no coincide con la de la base de datos
                    MostrarMensaje("La contraseña anterior no coincide", true);
                }
            }
            else
            {
                // Todos los campos deben estar llenos
                MostrarMensaje("Todos los campos son obligatorios", true);
            }
        }

        // Función para validar la contraseña
        private bool ValidarContrasena(string contrasena)
        {
            // La contraseña debe tener al menos 8 caracteres
            if (contrasena.Length < 8)
                return false;

            // La contraseña debe contener al menos un número
            if (!contrasena.Any(char.IsDigit))
                return false;

            // La contraseña debe contener al menos una letra mayúscula
            if (!contrasena.Any(char.IsUpper))
                return false;

            // La contraseña debe contener al menos una letra minúscula
            if (!contrasena.Any(char.IsLower))
                return false;

            // La contraseña debe contener al menos un carácter especial
            if (!contrasena.Any(c => !char.IsLetterOrDigit(c)))
                return false;

            return true;
        }

        private void MostrarMensaje(string mensaje, bool esError)
        {
            Lberror.Visible = true;
            Lberror.Text = mensaje;
            Lberror.CssClass = "alert " + (esError ? "alert-danger" : "alert-success");
        }
    }
}