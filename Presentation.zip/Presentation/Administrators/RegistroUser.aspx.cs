﻿using sacot.BLL.AdministratorsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Administrators
{
    public partial class RegistroUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            { 
                if (Session["IDUser"] != null)
                {
                    // Ocultar las alertas al cargar la página
                    Lbexito.Visible = false;
                    Lberror.Visible = false;
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
            }
            
        }
        // Método para obtener el IDRole a partir del valor seleccionado en el ListBox
        private int ObtenerIdRole(string tipoUsuario)
        {
            // Mapear el tipo de usuario al IDRole correspondiente
            if (tipoUsuario == "Administrador")
            {
                return 1; // ID del rol de administrador
            }
            else if (tipoUsuario == "Cliente")
            {
                return 2; // ID del rol de cliente
            }
            else
            {
                return 0; // Valor por defecto o manejo de error
            }
        }

        protected void BtnSiguiente_Click1(object sender, EventArgs e)
        {
            try
            {
                // Crear una instancia de RegUsuarioBLL
                RegUsuarioBLL regUsuarioBLL = new RegUsuarioBLL();

                // Crear un objeto Usuarios con los datos del formulario
                Usuarios usuario = new Usuarios();
                usuario.NombreUsuario = TxtUsuario.Text;
                usuario.Contrasena = TxtContrasena.Text;
                usuario.CorreoElectronico = TxtEmail.Text;
                usuario.Nombre = TxtNombre.Text;
                usuario.Apellido = TxtApellido.Text;
                usuario.ConfirmarContrasena = TxtConfirmarContrasena.Text;
                System.Web.UI.HtmlControls.HtmlSelect tipoUsuarioSelect = (System.Web.UI.HtmlControls.HtmlSelect)LstTipoUsuario;
                string tipoUsuarioSeleccionado = tipoUsuarioSelect.Value;
                usuario.IDRole = ObtenerIdRole(tipoUsuarioSeleccionado);
                string registroExitoso = "";

                // Validar la contraseña
                if (!ValidarContrasena(usuario.Contrasena))
                {
                    // Mostrar mensaje de error de contraseña no válida
                    MostrarMensaje("Error: La contraseña debe tener al menos 8 caracteres, incluyendo al menos un número, letras mayusculas, letras minusculas y un carácter especial.");
                    return; // Salir del método ya que la contraseña no es válida
                }

                // Llamar al método RegistrarUsuario de la instancia de RegUsuarioBLL
                if (usuario.IDRole != 0 && usuario.Nombre != "" && usuario.Contrasena != ""
                    && usuario.CorreoElectronico != "" && usuario.NombreUsuario != ""
                    && usuario.Apellido != "")
                {
                    //confirmacion de contraseñas, coinciden
                    if (usuario.Contrasena == usuario.ConfirmarContrasena)
                    {
                        registroExitoso = regUsuarioBLL.RegistrarUsuario(usuario);
                        if (registroExitoso == "Usuario registrado correctamente.")
                        {
                            // Mostrar mensaje de éxito y ocultar mensaje de error
                            MostrarMensajeExito("Usuario registrado exitosamente.");
                            LimpiarForm();
                        }
                        else
                        {
                            // Mostrar mensaje de error de usuario existente
                            MostrarMensajeError("Error: El usuario  ya existe en la base de datos.");
                        }
                    }
                    //no coinciden las contraseñas
                    else
                    {
                        // Mostrar mensaje de error de que las contraseñas no coinciden
                        MostrarMensajeError("Error: Las contraseñas no coinciden, ingrese nuevamente.");
                    }
                }
                else
                {
                    MostrarMensajeError("Error: Faltan campos por llenar.");
                }
            }
            catch (Exception ex)
            {
                // Mostrar mensaje de error general
                MostrarMensajeError("Error: " + ex.Message);
            }
        }

        private void MostrarMensajeError(string mensaje)
        {
            // Mostrar mensaje de error en la interfaz de usuario
            Lberror.Visible = true;
            Lberror.Text = mensaje;
            Lberror.CssClass = "alert alert-danger"; // Clase CSS para mostrar el mensaje como error
        }

        private void MostrarMensajeExito(string mensaje)
        {
            // Mostrar mensaje de éxito en la interfaz de usuario
            Lbexito.Visible = true;
            Lberror.Visible = false;
            Lbexito.Text = mensaje;
            Lbexito.CssClass = "alert alert-success"; // Clase CSS para mostrar el mensaje como éxito
        }

        private void MostrarMensaje(string mensaje)
        {
            // Mostrar mensaje en la interfaz de usuario
            Lbexito.Visible = false;
            Lberror.Visible = true;
            Lberror.Text = mensaje;
            Lberror.CssClass = "alert " + (mensaje.StartsWith("Error") ? "alert-danger" : "alert-success"); // Clase CSS para mostrar el mensaje como error o éxito
        }

        // Función para validar la contraseña
        private bool ValidarContrasena(string contrasena)
        {
            // La contraseña debe tener al menos 8 caracteres
            if (contrasena.Length < 8)
                return false;

            // La contraseña debe contener al menos un número
            if (!contrasena.Any(char.IsDigit))
                return false;

            // La contraseña debe contener al menos una letra mayúscula
            if (!contrasena.Any(char.IsUpper))
                return false;

            // La contraseña debe contener al menos una letra minúscula
            if (!contrasena.Any(char.IsLower))
                return false;

            // La contraseña debe contener al menos un carácter especial
            if (!contrasena.Any(c => !char.IsLetterOrDigit(c)))
                return false;

            return true;
        }

        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarForm();
        }
        //metodo para limpiar cajas de texto y listbox
        private void LimpiarForm()
        {
            TxtUsuario.Text = "";
            TxtContrasena.Text = "";
            TxtEmail.Text = "";
            TxtNombre.Text = "";
            TxtApellido.Text = "";
            TxtConfirmarContrasena.Text = "";
            LstTipoUsuario.SelectedIndex = -1;
        }
    }
}