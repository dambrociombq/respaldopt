﻿using sacot.BLL.AdministratorsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Administrators
{
    public partial class MenuAdmi : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] == null)
                {
                    Response.Redirect("../Common/Login.aspx");
                }
                else
                {
                    try
                    {
                        // Llamar al método en la capa de lógica de negocio para obtener el usuario y el tipo de usuario
                        MenuAdmiBLL menuadmibll = new MenuAdmiBLL();
                        Usuarios usuario = menuadmibll.ObtenerUsuarioYRole(Convert.ToInt32(Session["IDUser"]));

                        if (usuario != null)
                        {
                            string nombreUsuario = usuario.NombreUsuario;
                            string tipoUsuario = usuario.NombreRole;

                            // mostrar los datos
                            UsuarioLiteral.Text = nombreUsuario;
                            TipoUsuarioLiteral.Text = tipoUsuario;
                        }
                        else
                        {
                            // Manejar el caso en el que no se encuentre el usuario
                        }
                    }
                    catch (Exception ex)
                    {
                        // Manejar excepciones de manera adecuada (por ejemplo, loguear el error y mostrar un mensaje amigable al usuario)
                        Response.Write("Error al cargar la página: " + ex.Message);
                    }
                }
            }
        }
    }
}