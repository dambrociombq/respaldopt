﻿using sacot.BLL.AdministratorsBLL;
using sacot.Model;
using System;
using System.Web.UI;

namespace sacot.Presentation.Administrators
{
    public partial class ActualizarUsuario : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblError.Visible = false;
                if (Session["IDUser"] != null)
                {
                    CargarDatosUsuario();
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
                
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListaUser.aspx");
        }

        protected void btnActualizar_Click(object sender, EventArgs e)
        {
            ActualizarUsuarioEnBaseDeDatos();
        }

        private void CargarDatosUsuario()
        {
            if (Request.QueryString["Usuario"] != null)
            {
                int IDUsuario = Convert.ToInt32(Request.QueryString["Usuario"]);
                Usuarios usuario = ObtenerUsuarioPorID(IDUsuario);
                if (usuario != null)
                {
                    MostrarDatosUsuario(usuario);
                }
                else
                {
                    Response.Redirect("ListaUser.aspx");
                }
            }
            else
            {
                Response.Redirect("ListaUser.aspx");
            }
        }

        private Usuarios ObtenerUsuarioPorID(int IDUsuario)
        {
            ActualizarUsuarioBLL usuariosBLL = new ActualizarUsuarioBLL();
            return usuariosBLL.ObtenerUsuarioPorID(IDUsuario);
        }

        private void MostrarDatosUsuario(Usuarios usuario)
        {
            txtNombreUsuario.Text = usuario.NombreUsuario;
            txtCorreoElectronico.Text = usuario.CorreoElectronico;
            txtNombre.Text = usuario.Nombre;
            txtApellido.Text = usuario.Apellido;
            ddlNombreRole.SelectedValue = usuario.NombreRole;
            ddEstado.SelectedValue = usuario.Estado;
        }

        private void ActualizarUsuarioEnBaseDeDatos()
        {
            int IDUsuario = Convert.ToInt32(Request.QueryString["Usuario"]);
            Usuarios usuario = new Usuarios
            {
                IDUsuario = IDUsuario,
                NombreUsuario = txtNombreUsuario.Text,
                CorreoElectronico = txtCorreoElectronico.Text,
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                NombreRole = ddlNombreRole.SelectedValue,
                Estado = ddEstado.SelectedValue
            };

            ActualizarUsuarioBLL usuariosBLL = new ActualizarUsuarioBLL();
            string mensaje = usuariosBLL.ActualizarUsuario(usuario);


            // Si el mensaje indica éxito, redireccionar
            if (mensaje == "Usuario actualizado correctamente.")
            {
                Response.Redirect("ListaUser.aspx");
            }
            else
            {
                MostrarMensaje(mensaje);
            }

            
        }
        private void MostrarMensaje(string mensaje)
        {
            // Mostrar mensaje en la interfaz de usuario
            lblError.Visible = true;
            lblError.Text = mensaje;
            lblError.CssClass = "alert " + (mensaje.StartsWith("Error") ? "alert-danger" : "alert-success"); // Clase CSS para mostrar el mensaje como error o éxito
        }
    }
}
