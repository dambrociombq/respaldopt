﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Clients
{
    public partial class EncabePie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Si la página se carga por primera vez, ocultar el mensaje de error
                Lberror.Visible = false;
                TxbArea.Visible = false;
                RblEncabezado.SelectedValue = "No"; // Por defecto, no mostrar el área en el encabezado

                // Verificar si se ha enviado el parámetro Documento en la URL
                if (Request.QueryString["Documento"] == null)
                {
                    // Si es nulo, redireccionar a la página de plantillas
                    Response.Redirect("Plantillas.aspx");
                }
            }
        }

        protected void BtnSiguiente_Click(object sender, EventArgs e)
        {
            Lberror.Visible = false;
            string area = "";
            // Obtener los datos de la interfaz de usuario
            if (RblEncabezado.SelectedValue == "Si")
            {
                area = TxbArea.Text;
            }
            else
            {
                area = "";
            }
            bool mostrarLogo = CbMostrarLogo.Checked;
            bool mostrarNombreEmpresa = CbMostrarNombreEmpresa.Checked;
            bool contabilizarPaginas = CbContabilizarPaginas.Checked;

            // Crear una instancia de la clase de lógica de negocios
            EncabePieBLL encabePieBLL = new EncabePieBLL();
            DocumentoEncabezado encabezado = new DocumentoEncabezado
            {
                EncabezadoArea = area
            };
            // Crear una instancia de DocumentoPiePagina con los datos del pie de página
            DocumentoPiePagina piePagina = new DocumentoPiePagina
            {
                MostrarLogo = mostrarLogo,
                MostrarNombreEmpresa = mostrarNombreEmpresa,
                ContabilizarPaginas = contabilizarPaginas
            };
            int idEncabezado= encabePieBLL.InsertarDatosEncabezado(encabezado);
            // Llamar al método para insertar los datos del pie de página
            int idPiePagina = encabePieBLL.InsertarDatosPiePagina(piePagina);

            // Si se logró insertar el pie de página
            if (idPiePagina > 0)
            {
                // Obtener el ID del documento desde la consulta de la URL
                int idDocumento = Convert.ToInt32(Request.QueryString["Documento"]);

                // Llamar al método para editar el documento con los datos del encabezado y pie de página
                bool insertdoc = encabePieBLL.EditarDocumento(idDocumento, idEncabezado, idPiePagina);

                // Redirigir a la próxima página si la actualización de los datos es exitosa
                if (insertdoc)
                {
                    Response.Redirect("Autorizacion.aspx?Documento=" + idDocumento);
                }
                else
                {
                    MostrarError("Error al insertar los datos");
                }
            }
            else
            {
                MostrarError("Error al insertar los datos del pie de página");
            }
        }

        protected void RblEncabezado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RblEncabezado.SelectedValue == "Si")
            {
                TxbArea.Visible = true;
            }
            else
            {
                TxbArea.Visible = false;
            }
        }

        private void MostrarError(string mensaje)
        {
            Lberror.Visible = true;
            Lberror.Text = mensaje;
        }


        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            // Redirecciona a las plantillas
            Response.Redirect("Plantillas.aspx");
        }

        protected void BtnAtras_Click(object sender, EventArgs e)
        { 
            Response.Redirect("Portada.aspx");
        }
    }
}
