﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Clients
{
    public partial class VistaPreliMisDoc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    // Verificar si se ha pasado el parámetro "iddocumento" en la URL
                    if (Request.QueryString["Documento"] != null)
                    {
                        // Obtener el valor del parámetro "iddocumento" de la URL
                        int iddocumento = Convert.ToInt32(Request.QueryString["Documento"]);

                        // Utilizar la capa de lógica de negocios para obtener los datos binarios del PDF
                        byte[] pdfBytes = VistaPreliMisDocBLL.ObtenerPDFBytes(iddocumento);

                        if (pdfBytes != null && pdfBytes.Length > 0)
                        {
                            // Convertir los datos binarios del PDF a Base64
                            string pdfBase64 = Convert.ToBase64String(pdfBytes);

                            // Construir la etiqueta iframe para mostrar el PDF
                            string iframeHtml = $"<iframe src='data:application/pdf;base64,{pdfBase64}' style='width:100%; height:600px;' frameborder='0'></iframe>";

                            // Agregar el control iframe al div o panel en tu página donde deseas mostrar el PDF
                            divPdfContainerpreli.InnerHtml = iframeHtml;
                        }
                        else
                        {
                            // Manejar el caso en el que no se encontraron datos binarios para el PDF
                            divPdfContainerpreli.InnerHtml = "PDF no encontrado.";
                        }
                    }
                    else
                    {
                        Response.Redirect("Plantillas.aspx");
                    }
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }

            }
        }
    }
}