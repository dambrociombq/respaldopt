﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using HtmlAgilityPack;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;
using static iText.StyledXmlParser.Jsoup.Select.Evaluator;

namespace sacot.Presentation.Clients
{
    public partial class PlantGenerica : System.Web.UI.Page
    {
        private int currentTemaIndex = 0; 
        private List<PlantillaTemas> temasList;
        private List<PlantillaSubtemas> subtemasList;
        private int currentDocumentoTemaID = 0;
        protected string ContenidoTema { get; set; }
        protected string ContenidoSubtema { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null && Request.QueryString["Documento"] != null)
                {
                    Lberror.Visible = false;
                    int idDocumento = Convert.ToInt32(Request.QueryString["Documento"]);
                    Documento documento = ObtenerDocumento(idDocumento);
                    if (documento != null)
                    {
                        temasList = ObtenerTemas(documento.IDPlantilla);
                        Session["Temas"] = temasList;
                        subtemasList = new List<PlantillaSubtemas>(); // Inicializar subtemas
                        if (temasList != null && temasList.Count > 0)
                        {
                            currentTemaIndex = 0;
                            currentDocumentoTemaID = temasList[currentTemaIndex].PlantillaTemaID;
                            BtnGuardarSubTema.Visible = false;
                            Session["CurrentTemaIndex"] = 0;
                            Session["CurrentSubtemaIndex"] = 0;
                            MostrarTema(temasList[currentTemaIndex]);
                        }
                        else
                        {
                            MostrarError("No hay temas disponibles");
                        }
                    }
                    else
                    {
                        MostrarError("No se encontró el documento");
                    }
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
            }
            else
            {
                // Recuperar temas y subtemas de la sesión
                temasList = Session["Temas"] as List<PlantillaTemas>;
                subtemasList = Session["Subtemas"] as List<PlantillaSubtemas>;
            }
        }

        protected void BtnGuardarTema_Click(object sender, EventArgs e)
        {
            InsertarTema();
            int idt = Convert.ToInt32(Session["CurrentTemaIndex"]) + 1;
            // Verificar si hay subtemas para el tema actual
            subtemasList = ObtenerSubtemas(idt);

            if (subtemasList != null && subtemasList.Count > 0)
            {
                // Si hay subtemas, mostrar el primer subtema
                currentDocumentoTemaID = subtemasList[0].PlantillaSubtemaID;
                
                int currentSubtemaIndex = Convert.ToInt32(Session["CurrentSubtemaIndex"]);
                MostrarSubtema(subtemasList[currentSubtemaIndex]);

            }
            else
            {
                // Avanzar al siguiente tema o subtema si no hay subtemas para el tema actual
                AvanzarAlSiguienteTemaOSubtema();
            }
        }

        protected void BtnGuardarSubTema_Click(object sender, EventArgs e)
        {
            InsertarSubtema();
            Session["CurrentSubtemaIndex"] = Convert.ToInt16(Session["CurrentSubtemaIndex"]) + 1;
            int TemaIndex = Convert.ToInt32(Session["CurrentTemaIndex"]);
            int currentSubtemaIndex = Convert.ToInt32(Session["CurrentSubtemaIndex"]);
            currentSubtemaIndex = currentSubtemaIndex - 1;
            subtemasList = ObtenerSubtemas(TemaIndex+1);
            if (subtemasList != null && currentSubtemaIndex < subtemasList.Count-1)
            {
                // Si hay subtemas, mostrar el siguiente subtema
                currentSubtemaIndex++;
                currentDocumentoTemaID = TemaIndex;
                BtnGuardarTema.Visible = false;
                BtnGuardarSubTema.Visible = true;
                MostrarSubtema(subtemasList[currentSubtemaIndex]);
                Session["CurrentSubtemaIndex"] = currentSubtemaIndex; // Incrementar el índice de subtemas
            }
            else
            {
                // No hay más subtemas, avanzar al siguiente tema
                AvanzarAlSiguienteTemaOSubtema();
            }
        }

        private void AvanzarAlSiguienteTemaOSubtema()
        {
            int currentTemaIndex = Convert.ToInt32(Session["CurrentTemaIndex"]);

            if (currentTemaIndex < temasList.Count - 1) // Verificar si hay más temas disponibles
            {
                currentTemaIndex++;
                // Avanzar al siguiente tema 
                Session["CurrentTemaIndex"] = currentTemaIndex; // Actualizar la variable de sesión

                // Mostrar el siguiente tema
                currentDocumentoTemaID = temasList[currentTemaIndex].PlantillaTemaID;
                BtnGuardarTema.Visible = true;
                BtnGuardarSubTema.Visible = false;
                MostrarTema(temasList[currentTemaIndex]);
                // Obtener subtemas para el nuevo tema mostrado
                List<PlantillaSubtemas> subtemas = ObtenerSubtemas(currentTemaIndex);
                if (subtemas != null && subtemas.Count > 0)
                {
                    Session["CurrentSubtemaIndex"] = 0; // Reiniciar el índice de subtemas
                }
                else
                {
                    Session["CurrentSubtemaIndex"] = null; // No hay subtemas en el nuevo tema
                }
                Session["CurrentTemaIndex"] = currentTemaIndex; // Guardar el índice del tema actual
            }
            else
            {
                // No hay más temas disponibles, redireccionar
                int idDocumento = Convert.ToInt32(Request.QueryString["Documento"]);
                Response.Redirect("FormatoDoc.aspx?Documento=" + idDocumento);
            }
        }
        private void InsertarTema()
        {
            try
            {
                if (temasList != null && currentTemaIndex < temasList.Count)
                {
                    DocumentoTema documentoTema = new DocumentoTema();
                    documentoTema.DocumentoID = Convert.ToInt32(Request.QueryString["Documento"]);
                    documentoTema.Tema = LblTitulo.Text;
                    documentoTema.ContenidoTema = HiddenField1.Value;
                    PlantGenericaBLL plantGenericaBLL = new PlantGenericaBLL();
                    Session["IDDocumentoTema"] = plantGenericaBLL.InsertarDocumentoTema(documentoTema);
                }
                else
                {
                    MostrarError("No hay temas disponibles para insertar.");
                }
            }
            catch (Exception ex)
            {
                MostrarError("Error al insertar tema: " + ex.Message);
            }
        }

        private void InsertarSubtema()
        {
            try
            { 
                    DocumentoSubtema documentoSubtema = new DocumentoSubtema();
                    documentoSubtema.DocumentoTemaID = Convert.ToInt16(Session["IDDocumentoTema"]);
                    documentoSubtema.Subtema = LblTitulo.Text;
                    documentoSubtema.ContenidoSubtema = HiddenField1.Value;
                    PlantGenericaBLL plantGenericaBLL = new PlantGenericaBLL();
                    plantGenericaBLL.InsertarDocumentoSubtema(documentoSubtema);
              
            }
            catch (Exception ex)
            {
                MostrarError("Error al insertar subtema: " + ex.Message);
            }
        }
         
        private Documento ObtenerDocumento(int idDocumento)
        {
            MidocumentoBLL PpantGenericaBLL = new MidocumentoBLL();
            return PpantGenericaBLL.ObtenerDocumentoPorId(idDocumento);
        }

        private List<PlantillaTemas> ObtenerTemas(int idPlantilla)
        {
            PlantGenericaBLL plantillaBLL = new PlantGenericaBLL();
            return plantillaBLL.ObtenerTemasPorIdPlantilla(idPlantilla);
        }

        private List<PlantillaSubtemas> ObtenerSubtemas(int idPlantillaTema)
        {
            PlantGenericaBLL plantillaBLL = new PlantGenericaBLL();
            return plantillaBLL.ObtenerSubtemasPorIdTema(idPlantillaTema);
        }

        private void MostrarTema(PlantillaTemas tema)
        {
            BtnGuardarTema.Visible = true;
            BtnGuardarSubTema.Visible = false;
            LbTB.Text = "Tema: ";
            LblTitulo.Text = tema.Tema;
            ContenidoTema = tema.ContenidoTema;
            HiddenField1.Value = ContenidoTema;
            ScriptManager.RegisterStartupScript(this, GetType(), "MostrarTemaScript", "MostrarContenido('" + tema.ContenidoTema + "');", true);

        }

        private void MostrarSubtema(PlantillaSubtemas subtema)
        {
            BtnGuardarTema.Visible = false;
            BtnGuardarSubTema.Visible = true;
            LbTB.Text = "Subtema: ";
            LblTitulo.Text = subtema.Subtema;
            ContenidoSubtema=subtema.ContenidoSubtema;
            HiddenField1.Value = ContenidoSubtema;
            ScriptManager.RegisterStartupScript(this, GetType(), "MostrarSubtemaScript", "MostrarContenido('" + subtema.ContenidoSubtema + "');", true);
        }

        private void MostrarError(string mensaje)
        {
            Lberror.Visible = true;
            Lberror.Text = mensaje;
        }

        protected void BtnAtras_Click(object sender, EventArgs e)
        {
            int idDocumento = Convert.ToInt32(Request.QueryString["Documento"]);
            Response.Redirect("IndiceCambio.aspx?Documento=" + idDocumento);
        }
    }
}
