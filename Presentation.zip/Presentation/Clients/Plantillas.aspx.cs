﻿using sacot.BLL.ClientsBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Clients
{
    public partial class Plantillas : System.Web.UI.Page
    {
        public object Titulo { get; internal set; }
        public object PlantillaID { get; internal set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    BindPlantillas();
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
                
            }
        }
        private void BindPlantillas()
        {
            PlantillasBLL plantillasBLL = new PlantillasBLL();
            rptPlantillas.DataSource = plantillasBLL.GetPlantillas();
            rptPlantillas.DataBind();
        }
        protected void imgPlantillaView_Click(object sender, ImageClickEventArgs e)
        {
            // Obtener el ImageButton que disparó el evento
            ImageButton imgButton = (ImageButton)sender;

            // Obtener el CommandArgument (que contiene el ID de la plantilla) del ImageButton
            int plantillaId = Convert.ToInt32(imgButton.CommandArgument);

            // Ahora puedes utilizar plantillaId como el ID de la plantilla seleccionada
            // Por ejemplo, puedes redirigir a la página VistaPriliPlantilla.aspx y pasar plantillaId como parámetro
            Response.Redirect("VistaPriliPlantilla.aspx?plantilla=" + plantillaId);
        }
        
    }
}