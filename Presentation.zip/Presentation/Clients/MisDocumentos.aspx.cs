﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Clients
{
    public partial class MisDocumentos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    CargarDocumentos();
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
            }
        }

        protected void CargarDocumentos()
        {
            // Obtener el ID de usuario para mostrar solo sus documentos
            int idUser = Convert.ToInt32(Session["IDUser"]);
            MidocumentoBLL midocumentoBLL = new MidocumentoBLL();
            List<Documento> documentos = midocumentoBLL.ObtenerDocumentos(idUser);

            rptDocumentos.DataSource = documentos;
            rptDocumentos.DataBind();
        }

        protected void ImgPlantillaView_Click(object sender, ImageClickEventArgs e)
        {
            // Obtener el ImageButton que generó el evento
            ImageButton imgBtn = (ImageButton)sender;

            // Obtener el ID del documento asociado al ImageButton
            string documentoID = imgBtn.CommandArgument;

            // Redirigir a la página de vista previa con el ID del documento como parámetro
            Response.Redirect($"VistaPreliMisDoc.aspx?Documento={documentoID}");
        }

    }
}