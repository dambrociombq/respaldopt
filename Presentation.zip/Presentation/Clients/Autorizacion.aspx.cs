﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Clients
{
    public partial class Autorizacion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    Lberror.Visible = false;
                    // Verificar si se ha enviado el parámetro Documento en la URL
                    if (Request.QueryString["Documento"] == null)
                    {
                        //si es nulo se redirecciona a la pagina de plantillas
                        Response.Redirect("Plantillas.aspx");
                    }
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
                
            }
        }

        protected void BtnSiguiente_Click(object sender, EventArgs e)
        {
            

            // Validar que todos los TextBox estén llenos
            if (string.IsNullOrEmpty(TxbNombreReviso.Text) ||
                string.IsNullOrEmpty(TxbPuestoReviso.Text) ||
                string.IsNullOrEmpty(TxbNombreElaboro.Text) ||
                string.IsNullOrEmpty(TxbPuestoElaboro.Text) ||
                string.IsNullOrEmpty(TxbNombreAutorizo.Text) ||
                string.IsNullOrEmpty(TxbPuestoAutorizo.Text))
            {
                MostrarError("Todos los campos son obligatorios.");
                return;
            }

            // Crear una instancia de la clase de lógica de negocios
            AutorizacionBLL autorizacionBLL = new AutorizacionBLL();

            // Crear una instancia de Autorizaciones y asignar los valores de los TextBox
            Autorizaciones autorizacion = new Autorizaciones
            {
                NombreReviso = TxbNombreReviso.Text,
                PuestoReviso = TxbPuestoReviso.Text,
                NombreElaboro = TxbNombreElaboro.Text,
                PuestoElaboro = TxbPuestoElaboro.Text,
                NombreAutorizo = TxbNombreAutorizo.Text,
                PuestoAutorizo = TxbPuestoAutorizo.Text
            };

            // Llamar al método de inserción en la capa de lógica de negocios
            int idAutorizaciones = autorizacionBLL.InsertarDatos(autorizacion);

            // Si se logró capturar el id de las autorizaciones, se hará la edición del documento
            if (idAutorizaciones > 0)
            {
                // Obtener el ID del documento desde la consulta de la URL
                int idDocumento = Convert.ToInt32(Request.QueryString["Documento"]);

                // Llamar al método para editar el documento
                bool insertdoc = autorizacionBLL.EditarDocAutorizo(idDocumento, idAutorizaciones);

                // Redirigir a la próxima página si la actualización de los datos fue exitosa
                if (insertdoc)
                {
                    Response.Redirect("IndiceCambio.aspx?Documento=" + idDocumento);
                }
            }
            else
            {
                MostrarError("Error al insertar los datos");
            }
        } 

        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            //redirecciona a las plantillas
            Response.Redirect("Plantillas.aspx");
        }
        private void MostrarError(string mensaje)
        {
            Lberror.Visible = true;
            Lberror.Text = mensaje;
        }

        protected void BtnAtras_Click(object sender, EventArgs e)
        {
            int idDocumento = Convert.ToInt32(Request.QueryString["Documento"]);
            Response.Redirect("EncabePie.aspx?Documento=" + idDocumento);
        }
    }
}