﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Clients
{
    public partial class IndiceCambio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    Lberror.Visible = false;
                    // Verificar si se ha enviado el parámetro Documento en la URL
                    if (Request.QueryString["Documento"] == null)
                    {
                        //si es nulo se redirecciona a la pagina de plantillas
                        Response.Redirect("Plantillas.aspx");
                    }
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
                
            }
        }

        protected void BtnSiguiente_Click(object sender, EventArgs e)
        {
            int idDocumento = Convert.ToInt32(Request.QueryString["Documento"]);

            // Llamada al método para registrar el cambio en el historial
            string descripcionParrafo = "Creacion del documento";  
            string refParrafo = "";
            string refPagina = "";

            // Instanciar el gestor de historial de cambios de documentos
            IndiceCambioBLL indiceCambioBLL = new IndiceCambioBLL();

            // Registrar el cambio
            indiceCambioBLL.RegistrarCambio(idDocumento, descripcionParrafo, refParrafo, refPagina);

            // Redireccionar a la página EncabePie.aspx y enviar el ID del documento insertado como parámetro
            Response.Redirect($"PlantGenerica.aspx?Documento={idDocumento}");
        }

        protected void BtnAtras_Click(object sender, EventArgs e)
        {
            int idDocumento = Convert.ToInt32(Request.QueryString["Documento"]);
            Response.Redirect("Autorizacion.aspx?Documento=" + idDocumento); 
        }

        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Plantillas.aspx");

        }
    }
}