﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Clients
{
    public partial class VistaPriliPlantilla : System.Web.UI.Page
    {
        //metodo que se ejecuta al inicar la pagina
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    // Verificar si se ha pasado el parámetro "plantillaId" en la URL
                    if (Request.QueryString["plantilla"] != null)
                    {
                        // Obtener el valor del parámetro "plantillaId" de la URL
                        int plantillaId = Convert.ToInt32(Request.QueryString["plantilla"]);

                        // Utilizar la capa de lógica de negocios para obtener el pdfPath correspondiente al ID de la plantilla
                        string pdfPath = VistaPriliPlantillasBLL.ObtenerPDFPath(plantillaId);

                        // Puedes utilizar pdfPath como desees, por ejemplo, para mostrar el PDF en la página
                        if (!string.IsNullOrEmpty(pdfPath))
                        {
                            // Construir la etiqueta iframe para mostrar el PDF
                            string iframeHtml = $"<iframe src='../../PlantillasMD/{pdfPath}' style='width:100%; height:600px;' frameborder='0'></iframe>";

                            // Agregar el control iframe al div o panel en tu página donde deseas mostrar el PDF
                            divPdfContainer.InnerHtml = iframeHtml;
                        }
                        else
                        {
                            // Manejar el caso en el que no se encontró el PDF correspondiente al ID de la plantilla
                            divPdfContainer.InnerHtml = "PDF no encontrado.";
                        }
                    }
                    else
                    {
                        Response.Redirect("Plantillas.aspx");
                    }
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                }
                
            }
        } 


        protected void BtnCancelar_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Plantillas.aspx");
        }

        protected void BtnEditar_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Portada.aspx?plantilla=" + Request.QueryString["plantilla"]);
        }
    }
}