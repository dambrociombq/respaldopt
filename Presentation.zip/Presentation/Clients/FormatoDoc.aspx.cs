﻿using HtmlAgilityPack;
using iText.IO.Image;
using iText.Layout.Element;
using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using iText.Layout.Properties;
using iText.Layout.Layout;
using iText.Kernel.Colors;
using iText.Kernel.Pdf;
using iText.Kernel.Geom;
using iText.Layout.Borders;
using iText.Layout;
using iText.Kernel.Font;
using iText.IO.Font.Constants;

namespace sacot.Presentation.Clients
{
    public partial class FormatoDoc : System.Web.UI.Page
    {
        private GeneracionPDFBLL generacionPDFBLL = new GeneracionPDFBLL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["IDUser"] == null)
                {
                    Response.Redirect("../Common/Login.aspx");
                }
                else
                {
                    Lberror.Visible = false;
                    // Verificar si se ha enviado el parámetro Documento en la URL
                    if (Request.QueryString["Documento"] == null)
                    {
                        // Si es nulo, se redirecciona a la página de plantillas
                        Response.Redirect("Plantillas.aspx");
                    }
                }
            }
        }
         

        private string ObtenerValorSeleccionado(DropDownList DropDownList)
        {
            if (DropDownList != null && DropDownList.SelectedItem != null)
            {
                return DropDownList.SelectedItem.Text;
            }
            return string.Empty;
        }

        private void MostrarError(string mensaje)
        {
            Lberror.Visible = true;
            Lberror.Text = mensaje;
        }
         

        private bool ValidarCampos()
        {
            // Validar que se haya seleccionado una alineación para el logo
            if (DropDownListAlineacionLogo.SelectedIndex == -1)
            {
                MostrarError("Debe seleccionar una alineación para el logo.");
                return false;
            }

            // Validar que se haya seleccionado una alineación para la información de la portada
            if (DropDownListAlineacionInformacionPortada.SelectedIndex == -1)
            {
                MostrarError("Debe seleccionar una alineación para la información de la portada.");
                return false;
            }

            // Validar que se haya ingresado un color de texto para la portada
            if (string.IsNullOrWhiteSpace(TxbColorPortadax.Text))
            {
                MostrarError("Debe ingresar un color de texto para la portada.");
                return false;
            }

            // Validar que se haya seleccionado una alineación para el encabezado
            if (DropDownListAlineacionEncabezado.SelectedIndex == -1)
            {
                MostrarError("Debe seleccionar una alineación para el encabezado.");
                return false;
            }

            // Validar que se haya ingresado un color de texto para el encabezado
            if (string.IsNullOrWhiteSpace(TxbColorEnca.Text))
            {
                MostrarError("Debe ingresar un color de texto para el encabezado.");
                return false;
            }

            // Validar que se haya seleccionado una alineación para el pie de página
            if (DropDownListAlineacionPie.SelectedIndex == -1)
            {
                MostrarError("Debe seleccionar una alineación para el pie de página.");
                return false;
            }

            // Validar que se haya ingresado un color de texto para el pie de página
            if (string.IsNullOrWhiteSpace(TxbColorPie.Text))
            {
                MostrarError("Debe ingresar un color de texto para el pie de página.");
                return false;
            }

            // Validar que se haya seleccionado una alineación para los títulos
            if (DropDownListAlineacionTitulos.SelectedIndex == -1)
            {
                MostrarError("Debe seleccionar una alineación para los títulos.");
                return false;
            }

            // Validar que se haya ingresado un color de texto para los títulos
            if (string.IsNullOrWhiteSpace(TxbColorTitulo.Text))
            {
                MostrarError("Debe ingresar un color de texto para los títulos.");
                return false;
            }

            return true;
        }
         

        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Plantillas.aspx");
        }

        protected void BtnSiguiente_Click(object sender, EventArgs e)
        {
            if (ValidarCampos())
            {
                int idDocumento = Convert.ToInt16(Request.QueryString["Documento"]);
                InformacionDocumento informacionDocumento = new InformacionDocumento
                {
                    DocumentoID = idDocumento,
                    AlineacionLogoVertical = ObtenerValorSeleccionado(DropDownListAlineacionLogo),
                    AlineacionLogoHorizontal= ObtenerValorSeleccionado(DropDownListAlineacionLogoHorizontal),
                    AlineacionInformacionPortadaVertical = ObtenerValorSeleccionado(DropDownListAlineacionInformacionPortada),
                    AlineacionInformacionPortadaHorizontal = ObtenerValorSeleccionado(DropDownListAlineacionInformacionPortadaHorizontal),
                    ColorTextoPortada = TxbColorPortadax.Text,
                    AlineacionEncabezado = ObtenerValorSeleccionado(DropDownListAlineacionEncabezado),
                    ColorTextoEncabezado = TxbColorEnca.Text,
                    AlineacionPiePagina = ObtenerValorSeleccionado(DropDownListAlineacionPie),
                    ColorTextoPiePagina = TxbColorPie.Text,
                    AlineacionTitulos = ObtenerValorSeleccionado(DropDownListAlineacionTitulos),
                    ColorTextoTitulos = TxbColorTitulo.Text
                };

                InformacionDocumentoBLL informacionDocumentoBLL = new InformacionDocumentoBLL();
                try
                {
                    informacionDocumentoBLL.InsertarInformacionDocumento(informacionDocumento);
                    //llamar al metodo para generar el pdf
                    BtnGenerar_Click();
                    // Redireccionar a otra pagina
                    Response.Redirect("VistaPreliMisDoc.aspx?Documento=" + Request.QueryString["Documento"]);
                }
                catch (Exception ex)
                {
                    MostrarError("Error al guardar la información del documento: " + ex.Message);
                }
            }
        }
        //metodos para generar el PDF
        private void BtnGenerar_Click()
        {
            int idDocumento = Convert.ToInt16(Request.QueryString["Documento"]);
            Documento documento = new Documento();
            InformacionDocumento informacionDocumento = new InformacionDocumento();

            // Obtener documento por ID
            documento = generacionPDFBLL.ObtenerDocumentoPorId(idDocumento);

            // Obtener información del documento por ID
            informacionDocumento = generacionPDFBLL.ObtenerInformacionDocumentoPorId(idDocumento);

            // Obtener la portada del documento por ID
            DocumentoPortada portada = generacionPDFBLL.ObtenerDocumentoPortadaPorId(documento.DocumentoPortadaID);

            // Obtener el encabezado del documento por ID
            DocumentoEncabezado encabezado = generacionPDFBLL.ObtenerDocumentoEncabezadoPorId(documento.DocumentoEncabezadoID);

            // Obtener el pie de página del documento por ID
            DocumentoPiePagina piePagina = generacionPDFBLL.ObtenerDocumentoPiePaginaPorId(documento.DocumentoPiePaginaID);

            // Obtener autorización por ID
            Autorizaciones autorizacion = generacionPDFBLL.ObtenerAutorizacionPorId(documento.AutorizacionID);

            // Obtener historial de cambios por ID
            List<HistorialCambioDocumento> cambio = generacionPDFBLL.ObtenerHistorialCambioDocumentoPorId(idDocumento);

            // Obtener temas del documento por ID
            List<DocumentoTema> temas = generacionPDFBLL.ObtenerDocumentoTemasPorId(idDocumento);

            // Obtener subtemas para cada tema y agregarlos a la lista de subtemas
            List<DocumentoSubtema> subtemas = new List<DocumentoSubtema>();
            foreach (DocumentoTema tema in temas)
            {
                int documentotemaID = tema.DocumentoTemaID;
                List<DocumentoSubtema> subtemasTemp = generacionPDFBLL.ObtenerDocumentoSubtemasPorId(documentotemaID);
                subtemas.AddRange(subtemasTemp);
            }

            // Una vez que todas las tareas se completen, generar PDF
            byte[] pdfBytes = GenerarPDF(portada, temas, subtemas, documento, informacionDocumento, piePagina, encabezado,  cambio, autorizacion);

            // Actualizar el campo ArchivoPDF en la base de datos
            generacionPDFBLL.ActualizarArchivoPDF(idDocumento, pdfBytes);
        }


        public byte[] GenerarPDF(DocumentoPortada portada, List<DocumentoTema> temas, List<DocumentoSubtema> subtemas, Documento documento, InformacionDocumento informacionDocumento, DocumentoPiePagina piePagina, DocumentoEncabezado encabezado, List<HistorialCambioDocumento> cambios, Autorizaciones autorizacion)
        {
            using (MemoryStream memoryStream = new MemoryStream())
            {
                // Inicializar el escritor PDF
                using (iText.Kernel.Pdf.PdfWriter writer = new iText.Kernel.Pdf.PdfWriter(memoryStream))
                {
                    // Inicializar el documento PDF de iText
                    using (iText.Kernel.Pdf.PdfDocument pdf = new iText.Kernel.Pdf.PdfDocument(writer))
                    {
                        // Agregar página en blanco al principio del documento
                        pdf.AddNewPage();

                        // Crear una instancia de HeaderFooterHandler para manejar el encabezado y el pie de página
                        HeaderFooterHandler handler = new HeaderFooterHandler(encabezado.EncabezadoArea, temas, subtemas, piePagina, portada, informacionDocumento );

                        // Agregar encabezado y pie de página a todas las páginas
                        pdf.AddEventHandler(iText.Kernel.Events.PdfDocumentEvent.END_PAGE, handler);

                        // Inicializar el documento de iText
                        iText.Layout.Document document = new iText.Layout.Document(pdf);
                        // Márgenes: arriba, derecha, abajo, izquierda
                        document.SetMargins(72 * 2.5f, 50, 72 * 2.5f, 50);

                        // Agregar la portada
                        handler.AgregarPortada(document, portada, informacionDocumento);
                        document.Add(new AreaBreak());

                        // Agregar tabla de autorizaciones
                        handler.AgregarTablaAutorizaciones(document, autorizacion);

                        // Agregar tabla de índice de cambios
                        handler.AgregarTablaIndiceCambios(document, cambios, autorizacion);

                        //agregar el indice
                        //handler.AgregarIndice(document, temas, subtemas);

                        // Agregar contenido al documento (temas y subtemas)
                        handler.AgregarContenido(document, temas, subtemas, informacionDocumento);

                        // Cerrar el documento
                        document.Close();
                    }
                }

                // Obtener el contenido del documento como arreglo de bytes
                byte[] pdfBytes = memoryStream.ToArray();
                return pdfBytes;
            }
        }

        // Clase para manejar el evento de encabezado y pie de página
        public class HeaderFooterHandler : iText.Kernel.Events.IEventHandler
        {
            private string titulo;
            private string encabezadoArea;
            private DateTime fechaElaboracion;
            private DateTime fechaRevision;
            private string codigo;
            private byte[] logo; 
            private List<DocumentoTema> temas;
            private List<DocumentoSubtema> subtemas;
            private bool isPortada = true; // Añadir un indicador para identificar si la página actual es la portada
            private DocumentoPiePagina pie;
            private DocumentoPortada port;
            private InformacionDocumento informacionDocumento; 
            public HeaderFooterHandler(  string encabezadoArea,   List<DocumentoTema> temas, List<DocumentoSubtema> subtemas, DocumentoPiePagina pie, DocumentoPortada port, InformacionDocumento informacionDocumento )
            {
                this.titulo = port.Titulo;
                this.encabezadoArea = encabezadoArea;
                this.fechaElaboracion = port.FechaElaboracion;
                this.fechaRevision = port.FechaRevision;
                this.codigo = port.Codigo;
                this.logo = port.Logo; 
                this.temas = temas;
                this.subtemas = subtemas;
                this.pie= pie;
                this.port = port;
                this.informacionDocumento = informacionDocumento; 
            }
            //metodo para manejar el pie de pagina y el encabezado
            public void HandleEvent(iText.Kernel.Events.Event @event)
            {
                iText.Kernel.Events.PdfDocumentEvent docEvent = (iText.Kernel.Events.PdfDocumentEvent)@event;
                iText.Layout.Canvas canvas = new iText.Layout.Canvas(docEvent.GetPage(), docEvent.GetDocument().GetDefaultPageSize());

                if (!isPortada) // Agregar encabezado y pie de página solo si no es la portada
                {
                    // Agregar encabezado
                    AgregarEncabezado(canvas, docEvent );

                    // Agregar pie de página
                    AgregarPieDePagina(canvas, docEvent, pie, port, informacionDocumento);
                }

                isPortada = false; // Después de la primera página, no es la portada
            }
            public void AgregarPortada(iText.Layout.Document document, DocumentoPortada portada, InformacionDocumento informacion)
            {
                // Convertir byte[] a iText Image
                iText.Layout.Element.Image itextImage = new iText.Layout.Element.Image(ImageDataFactory.Create(portada.Logo));

                // Obtener la alineación del logo de forma vertical y horizontal
                VerticalAlignment alineacionLogoVertical = ConvertirAlineacionVertical(informacion.AlineacionLogoVertical);
                HorizontalAlignment alineacionLogoHorizontal = ConvertirAlineacionHorizontal(informacion.AlineacionLogoHorizontal);

                // Aplicar alineaciones al logo
                itextImage.SetProperty(Property.VERTICAL_ALIGNMENT, alineacionLogoVertical);
                itextImage.SetProperty(Property.HORIZONTAL_ALIGNMENT, alineacionLogoHorizontal);

                // Establecer la altura deseada de la imagen (4 cm)
                float alturaEnCm = 4f;
                float alturaEnPuntos = alturaEnCm * 28.35f;
                itextImage.SetHeight(alturaEnPuntos);

                // Obtener el ancho original de la imagen
                float anchoOriginal = itextImage.GetImageWidth();

                // Calcular el ancho deseado manteniendo la relación de aspecto
                float anchoDeseado = (alturaEnPuntos / itextImage.GetImageHeight()) * anchoOriginal;

                // Autoajustar el ancho manteniendo la relación de aspecto original
                itextImage.SetWidth(anchoDeseado);

                // Agregar la imagen al documento PDF
                document.Add(itextImage);
                // Obtener el color del texto de la portada y convertirlo a DeviceRgb
                DeviceRgb colorTexto = ColorConverter(informacion.ColorTextoPortada);

                
                // Aplicar alineaciones y color al texto en la tabla 
                TextAlignment alineacionHorizontalTabla = (TextAlignment)ConvertirAlineacionHorizontal(informacion.AlineacionInformacionPortadaHorizontal);
                VerticalAlignment alineacionVerticalTabla = ConvertirAlineacionVertical(informacion.AlineacionInformacionPortadaVertical);


                // Crear el párrafo con el título y el código
                Paragraph portadaInfo = new Paragraph();
                portadaInfo.Add("Titulo\n");
                portadaInfo.Add(portada.Titulo + "\n");
                portadaInfo.Add("Código\n");
                portadaInfo.Add(portada.Codigo);

                // Aplicar color de texto, alineación vertical y alineación horizontal
                portadaInfo.SetFontColor(colorTexto);
                portadaInfo.SetTextAlignment(alineacionHorizontalTabla);
                portadaInfo.SetVerticalAlignment(alineacionVerticalTabla); 

                // Agregar la tabla al documento
                document.Add(portadaInfo);


                // Crear tabla con la información de la portada
                iText.Layout.Element.Table tablaPortada = new iText.Layout.Element.Table(new float[] { 1, 1 });
                tablaPortada.SetWidth(UnitValue.CreatePercentValue(100));

                tablaPortada.SetTextAlignment((TextAlignment?)alineacionHorizontalTabla);
                tablaPortada.SetVerticalAlignment((VerticalAlignment?)alineacionVerticalTabla);
                tablaPortada.SetFontColor(colorTexto);

                // Añadir filas a la tabla con la información de la portada
                AñadirCelda(tablaPortada, "Elaboró:", portada.Elaboro, alineacionHorizontalTabla, alineacionVerticalTabla, colorTexto);
                AñadirCelda(tablaPortada, "Versión:", portada.Version, alineacionHorizontalTabla, alineacionVerticalTabla, colorTexto);
                AñadirCelda(tablaPortada, "Fecha de Elaboración:", portada.FechaElaboracion.ToString("dd/MM/yyyy"), alineacionHorizontalTabla, alineacionVerticalTabla, colorTexto);
                AñadirCelda(tablaPortada, "Fecha de Revisión:", portada.FechaRevision.ToString("dd/MM/yyyy"), alineacionHorizontalTabla, alineacionVerticalTabla, colorTexto);

                // Agregar la tabla al documento
                document.Add(tablaPortada);
            }

            // Método para añadir una celda a la tabla
            private void AñadirCelda(iText.Layout.Element.Table tabla, string titulo, string contenido, TextAlignment alineacionHorizontal, VerticalAlignment alineacionVertical, DeviceRgb colorTexto)
            {
                // Añadir celda con el título
                tabla.AddCell(new Cell().Add(new Paragraph(titulo)
                    .SetTextAlignment(alineacionHorizontal)
                    .SetVerticalAlignment(alineacionVertical)
                    .SetFontColor(colorTexto)));
                // Añadir celda con el contenido
                tabla.AddCell(new Cell().Add(new Paragraph(contenido)
                    .SetTextAlignment(alineacionHorizontal)
                    .SetVerticalAlignment(alineacionVertical)
                    .SetFontColor(colorTexto)));
            }

            // Método para convertir el código RGB a DeviceRgb
            private DeviceRgb ColorConverter(string colorTexto)
            {
                // Remover el "#" si está presente
                colorTexto = colorTexto.Replace("#", "");

                // Extraer los componentes RGB
                int r = int.Parse(colorTexto.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
                int g = int.Parse(colorTexto.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
                int b = int.Parse(colorTexto.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);

                // Retornar el color como un objeto DeviceRgb
                return new DeviceRgb(r, g, b);
            }

            // Método para convertir la alineación vertical de string a VerticalAlignment de iText
            private VerticalAlignment ConvertirAlineacionVertical(string alineacionVertical)
            {
                switch (alineacionVertical)
                {
                    case "Arriba":
                        return VerticalAlignment.TOP;
                    case "Centro":
                        return VerticalAlignment.MIDDLE;
                    case "Abajo":
                        return VerticalAlignment.BOTTOM;
                    default:
                        return VerticalAlignment.MIDDLE;
                }
            }

            // Método para convertir la alineación horizontal de string a TextAlignment de iText
            private HorizontalAlignment ConvertirAlineacionHorizontal(string alineacion)
            {
                switch (alineacion)
                {
                    case "Izquierda":
                        return HorizontalAlignment.LEFT;
                    case "Centro":
                        return HorizontalAlignment.CENTER;
                    case "Derecha":
                        return HorizontalAlignment.RIGHT;
                    default:
                        return HorizontalAlignment.LEFT; // Otra opción por defecto
                }
            }
            
            public void AgregarContenido(iText.Layout.Document document, List<DocumentoTema> temas, List<DocumentoSubtema> subtemas, InformacionDocumento informacion)
            {
                 
                DeviceRgb colorTexto = ColorConverter(informacion.ColorTextoTitulos);

                int numeroTema = 1; // Iniciar contador de temas
                foreach (var tema in temas)
                {
                    FormatoDoc instancia = new FormatoDoc();

                    // Interpretar las etiquetas HTML del tema y extraer el texto enriquecido
                    string contenidoTemaEnriquecido = instancia.InterpretarEtiquetasHtml(tema.ContenidoTema);

                    // Agregar el título del tema al documento
                    if(tema.Tema != "")//si el tema no es vacio
                    {
                        Paragraph tituloTema = new Paragraph($"{numeroTema}. {tema.Tema}")
                        .SetFontSize(16)
                        .SetTextAlignment((TextAlignment?)ConvertirAlineacionHorizontal(informacion.AlineacionTitulos))
                        .SetFontColor(colorTexto);
                        document.Add(tituloTema);
                    }
                    else
                    {
                        //si el tema es vacio, solo mostrar su contenido
                        // Crear un párrafo con el texto deseado
                        Paragraph paragraph = new Paragraph(tema.Tema);

                        // Agregar el párrafo al documento
                        document.Add(paragraph); 
                    }
                    
                    // Agregar contenido enriquecido del tema al documento
                    Paragraph contenidoTema = new Paragraph(contenidoTemaEnriquecido)
                        .SetTextAlignment(TextAlignment.JUSTIFIED);
                    document.Add(contenidoTema);
                    // Buscar subtemas relacionados con el tema actual
                    var subtemasRelacionados = subtemas.Where(subtema => subtema.DocumentoTemaID == tema.DocumentoTemaID);
                    int numeroSubtema = 1; // Iniciar contador de subtemas

                    // Agregar los subtemas al documento
                    foreach (var subtema in subtemasRelacionados)
                    {
                        FormatoDoc instanciasub = new FormatoDoc();

                        // Interpretar las etiquetas HTML del subtema y extraer el texto enriquecido
                        string contenidoSubtemaEnriquecido = instanciasub.InterpretarEtiquetasHtml(subtema.ContenidoSubtema);

                        // Agregar el título del subtema al documento
                        Paragraph tituloSubtema = new Paragraph($"{numeroTema}.{numeroSubtema} {subtema.Subtema}")
                            .SetFontSize(14)
                            .SetTextAlignment((TextAlignment?)ConvertirAlineacionHorizontal(informacion.AlineacionTitulos))
                            .SetFontColor(colorTexto);
                        document.Add(tituloSubtema);

                        // Agregar contenido enriquecido del subtema al documento
                        Paragraph contenidoSubtema = new Paragraph(contenidoSubtemaEnriquecido)
                            .SetTextAlignment(TextAlignment.JUSTIFIED);
                        document.Add(contenidoSubtema);

                        numeroSubtema++; // Incrementar contador de subtemas
                    }

                    numeroTema++; // Incrementar contador de temas
                }
            }

            private void AgregarEncabezado(iText.Layout.Canvas canvas, iText.Kernel.Events.PdfDocumentEvent docEvent)
            {
                // Crear tabla para el encabezado con dos columnas de igual ancho 
                iText.Layout.Element.Table table = new iText.Layout.Element.Table(new float[] { 1, 1 }); // Ambas columnas tienen el mismo ancho

                // Ajustar los márgenes izquierdo y derecho a 1.5 cm
                float marginLeftCm = 1.5f; // Margen izquierdo de 1.5 cm
                float marginRightCm = 1.5f; // Margen derecho de 1.5 cm
                float marginLeftPts = marginLeftCm / 2.54f * 72; // Convertir cm a pulgadas y luego a puntos
                float marginRightPts = marginRightCm / 2.54f * 72; // Convertir cm a pulgadas y luego a puntos

                // Establecer los márgenes en la tabla
                table.SetMargins(marginLeftPts, marginRightPts, marginLeftPts, 0);

                // Agregar título al encabezado con tamaño 12
                Paragraph title = new Paragraph(titulo)
                    .SetFontSize(12);

                Cell titleCell = new Cell().Add(title);
                Cell logoCell = new Cell().SetHorizontalAlignment(iText.Layout.Properties.HorizontalAlignment.RIGHT);
                if (logo != null && logo.Length > 0)
                {
                    byte[] imageData = logo;
                    ImageData imageDataObj = ImageDataFactory.Create(imageData);
                    iText.Layout.Element.Image logoImage = new iText.Layout.Element.Image(imageDataObj);

                    // Fijar la altura en 1.40 cm
                    float desiredHeightCm = 1.40f; // Altura deseada en centímetros
                    float desiredHeightPts = desiredHeightCm / 2.54f * 72; // Convertir cm a pulgadas y luego a puntos

                    // Ajustar el ancho manteniendo la relación de aspecto original
                    float originalWidthPts = logoImage.GetImageWidth();
                    float originalHeightPts = logoImage.GetImageHeight();
                    float aspectRatio = originalWidthPts / originalHeightPts;
                    float adjustedWidthPts = desiredHeightPts * aspectRatio;

                    logoImage.SetHeight(desiredHeightPts);
                    logoImage.SetWidth(adjustedWidthPts); // Ajustar el ancho según la relación de aspecto
                    logoImage.SetAutoScaleWidth(false); // Deshabilitar el ajuste automático del ancho

                    logoCell.Add(logoImage);
                }
                table.AddCell(titleCell);
                table.AddCell(logoCell);
                
                // Agregar área al encabezado si no es null
                if (!string.IsNullOrEmpty(encabezadoArea))
                {
                    table.AddCell(new Cell().Add(new Paragraph("Area")))
                        .SetFontSize(10);
                    Cell areaCell = new Cell().Add(new Paragraph(encabezadoArea))
                        .SetFontSize(10);
                    table.AddCell(areaCell);

                    // Ajustar startY para que la tabla comience a la mitad de la distancia entre la tabla y el margen superior de la hoja
                    float startY = docEvent.GetPage().GetPageSize().GetTop() - (1.25f / 2.54f * 72 - 28.35f) / 2 - 28.35f; // Posición Y en la parte superior de la página, con un ajuste de 1 cm
                    startY -= 125f; // Ajuste adicional para el logo
                    table.SetFixedPosition(marginLeftPts, startY, docEvent.GetPage().GetPageSize().GetWidth() - marginLeftPts - marginRightPts);
                }
                else
                {
                    // Si no hay área, agregar 2 cm más abajo
                    float startY = docEvent.GetPage().GetPageSize().GetTop() - 28.35f - 100; // Posición Y 2 cm debajo del límite superior de la página
                    table.SetFixedPosition(marginLeftPts, startY, docEvent.GetPage().GetPageSize().GetWidth() - marginLeftPts - marginRightPts);
                }



                // Agregar fechas y código al encabezado
                table.AddCell(new Cell().Add(new Paragraph("Fecha de Publicación")))
                    .SetFontSize(10);
                table.AddCell(new Cell().Add(new Paragraph("Fecha de Revisión")))
                    .SetFontSize(10);
                table.AddCell(new Cell().Add(new Paragraph(fechaElaboracion.ToString("dd/MM/yyyy"))))
                    .SetFontSize(10);
                table.AddCell(new Cell().Add(new Paragraph(fechaRevision.ToString("dd/MM/yyyy"))))
                    .SetFontSize(10);
                table.AddCell(new Cell().Add(new Paragraph("Código")))
                    .SetFontSize(10);
                table.AddCell(new Cell().Add(new Paragraph(codigo)))
                    .SetFontSize(10);

                // Agregar tabla al encabezado con posición fija
                canvas.Add(table);
            } 

            private void AgregarPieDePagina(iText.Layout.Canvas canvas, iText.Kernel.Events.PdfDocumentEvent docEvent, DocumentoPiePagina piepag, DocumentoPortada port, InformacionDocumento informacionDocumento)
            {
                float marginLeft = 72 * 2.5f;
                float marginRight = 72 * 2.5f;
                float footerMargin = 20;
                float marginBottom = 72 * 2.54f;
                float footerY = docEvent.GetPage().GetPageSize().GetBottom() + footerMargin;

                Div footer = new Div();
                float pageWidth = docEvent.GetPage().GetPageSize().GetWidth();
                float footerWidth = pageWidth - marginLeft - marginRight;

                iText.Layout.Element.Table table = new iText.Layout.Element.Table(new float[] { 1, 1, 1 }); // 3 columnas

                table.SetWidth(UnitValue.CreatePointValue(footerWidth));

                Cell cell = new Cell();
                cell.SetBorder(Border.NO_BORDER);
                cell.SetTextAlignment(TextAlignment.CENTER);

                if (piepag.MostrarLogo)
                {
                    iText.Layout.Element.Image image = new iText.Layout.Element.Image(iText.IO.Image.ImageDataFactory.Create(port.Logo));
                    float desiredWidth = 28.35f;
                    float aspectRatio = image.GetImageWidth() / image.GetImageHeight();
                    float desiredHeight = desiredWidth / aspectRatio;
                    image.SetWidth(desiredWidth);
                    image.SetHeight(desiredHeight);
                    cell.Add(new Paragraph().Add(image));
                }

                if (piepag.MostrarNombreEmpresa)
                {
                    cell.Add(new Paragraph(port.NombreEmpresa))
                        .SetFontSize(10);
                }

                if (piepag.ContabilizarPaginas)
                {
                    cell.Add(new Paragraph("Página " + docEvent.GetDocument().GetPageNumber(docEvent.GetPage())))
                        .SetFontSize(10);
                }

                table.AddCell(cell);
                table.SetTextAlignment(TextAlignment.CENTER);

                footerY = docEvent.GetPage().GetPageSize().GetBottom() + footerMargin;
                table.SetFixedPosition(marginLeft, footerY, footerWidth);

                canvas.Add(table);
            }
            public void AgregarTablaAutorizaciones(iText.Layout.Document document, Autorizaciones autorizacion)
            {
                // Crear la tabla de autorizaciones con una columna
                iText.Layout.Element.Table tablaAutorizaciones = new iText.Layout.Element.Table(1);
                tablaAutorizaciones.SetWidth(UnitValue.CreatePercentValue(100));

                // Estilo para los bordes de la tabla
                SolidBorder borde = new SolidBorder(ColorConstants.GRAY, 1);

                // Añadir el título a la tabla
                Cell cellTitulo = new Cell(1, 1).Add(new Paragraph("Autorizaciones")
                                            .SetFontColor(ColorConstants.BLACK)
                                            .SetBold()
                                            .SetFontSize(16)
                                            .SetTextAlignment(TextAlignment.CENTER));

                tablaAutorizaciones.AddHeaderCell(cellTitulo);
                // Añadir filas a la tabla de autorizaciones
                AñadirFilaEnca(tablaAutorizaciones, "Elaboró", autorizacion.NombreElaboro, autorizacion.PuestoElaboro, borde);
                AñadirFilaEnca(tablaAutorizaciones, "Revisó", autorizacion.NombreReviso, autorizacion.PuestoReviso, borde);
                AñadirFilaEnca(tablaAutorizaciones, "Autorizó", autorizacion.NombreAutorizo, autorizacion.PuestoAutorizo, borde);

                // Añadir la tabla de autorizaciones al documento
                 tablaAutorizaciones.SetTextAlignment(TextAlignment.CENTER);
                // Añadir la tabla de autorizaciones al documento
                Paragraph paragraph = new Paragraph().SetTextAlignment(TextAlignment.CENTER);
                paragraph.Add(tablaAutorizaciones);
                document.Add(paragraph);

                // Agregar un salto de página
                document.Add(new AreaBreak());
            }

            // Método para añadir una fila a la tabla de autorizaciones
            private void AñadirFilaEnca(iText.Layout.Element.Table tabla, string encabezado, string nombre, string puesto, SolidBorder borde)
            {
                // Añadir encabezado de fila con estilo
                tabla.AddCell(CrearCeldaEncabezadoEnca(encabezado, borde));

                // Añadir contenido de fila con estilo
                tabla.AddCell(CrearCeldaContenidoEnca(nombre,puesto, borde)); 
            }

            // Método para crear celda de encabezado con estilo
            private Cell CrearCeldaEncabezadoEnca(string contenido,  SolidBorder borde)
            {
                return new Cell()
                    .Add(new Paragraph(contenido)
                        .SetFontColor(ColorConstants.BLACK)
                        .SetBold()
                        .SetTextAlignment(TextAlignment.CENTER))
                    .SetBorder(borde);
            }

            // Método para crear celda de contenido con estilo
            private Cell CrearCeldaContenidoEnca(string contenido, string puesto, SolidBorder borde)
            {
                return new Cell()
                    .Add(new Paragraph(contenido+" ("+puesto+")")
                        .SetTextAlignment(TextAlignment.CENTER))
                    .SetBorder(borde);
            }



            public void AgregarTablaIndiceCambios(iText.Layout.Document document, List<HistorialCambioDocumento> cambios, Autorizaciones autorizacion)
            {
                // Crear la tabla de índice de cambios
                iText.Layout.Element.Table tablaCambios = new iText.Layout.Element.Table(new float[] { 1, 1, 1, 1, 1 });
                tablaCambios.SetWidth(UnitValue.CreatePercentValue(100));

                // Añadir título a la tabla
                Cell cellTitulo = new Cell(1, 5).Add(new Paragraph("Índice de Cambios")
                                        .SetFontColor(ColorConstants.BLACK)
                                        .SetBold()
                                        .SetFontSize(16)
                                        .SetTextAlignment(TextAlignment.CENTER));
                tablaCambios.AddHeaderCell(cellTitulo);

                // Añadir encabezados de columna 
                tablaCambios.AddCell(new Cell().Add(new Paragraph("No.Revisión")));
                tablaCambios.AddCell(new Cell().Add(new Paragraph("Fecha")));
                tablaCambios.AddCell(new Cell().Add(new Paragraph("Descripción del cambio")));
                tablaCambios.AddCell(new Cell().Add(new Paragraph("Ref.Parrafo")));
                tablaCambios.AddCell(new Cell().Add(new Paragraph("Ref.Página")));

                int i = 1;
                // Añadir datos de cambios a la tabla
                foreach (var cambio in cambios)
                {
                    tablaCambios.AddCell(new Cell().Add(new Paragraph(i.ToString())));
                    tablaCambios.AddCell(new Cell().Add(new Paragraph(cambio.Fecha.ToString())));
                    tablaCambios.AddCell(new Cell().Add(new Paragraph(cambio.DescripcionParrafo)));
                    tablaCambios.AddCell(new Cell().Add(new Paragraph(cambio.RefParrafo)));
                    tablaCambios.AddCell(new Cell().Add(new Paragraph(cambio.RefPagina)));
                    i++;
                }

                // Agregar la última fila con tres columnas
                tablaCambios.AddCell(new Cell(1, 2).Add(new Paragraph("Elaborado por:").SetBold()));
                tablaCambios.AddCell(new Cell(1, 1).Add(new Paragraph("Revisado por:").SetBold()));
                tablaCambios.AddCell(new Cell(1, 2).Add(new Paragraph("Aprobado por:").SetBold()));

                tablaCambios.AddCell(new Cell(1, 2).Add(new Paragraph(autorizacion.PuestoElaboro)));
                tablaCambios.AddCell(new Cell(1, 1).Add(new Paragraph(autorizacion.PuestoReviso)));
                tablaCambios.AddCell(new Cell(1, 2).Add(new Paragraph(autorizacion.PuestoAutorizo)));

                // Crear el párrafo para contener la tabla y centrarla horizontalmente
                tablaCambios.SetTextAlignment(TextAlignment.CENTER);
                Paragraph paragraph = new Paragraph().SetTextAlignment(TextAlignment.CENTER);
                // Agregar la tabla al párrafo
                paragraph.Add(tablaCambios);

                // Agregar el párrafo al documento
                document.Add(paragraph);

                // Agregar un salto de página
                document.Add(new AreaBreak());
            }
        }


        // Método para interpretar las etiquetas HTML y extraer el texto enriquecido
        private string InterpretarEtiquetasHtml(string html)
        {
            HtmlDocument documentoHtml = new HtmlDocument();
            documentoHtml.LoadHtml(html);

            // Procesar el documento HTML y extraer el texto enriquecido manteniendo el formato
            StringBuilder textoEnriquecido = new StringBuilder();
            ProcesarNodosHtml(documentoHtml.DocumentNode.ChildNodes, textoEnriquecido);

            return textoEnriquecido.ToString();
        }

        // Método recursivo para procesar nodos HTML y extraer el texto manteniendo el formato
        private void ProcesarNodosHtml(HtmlNodeCollection nodos, StringBuilder textoEnriquecido)
        {
            foreach (HtmlNode nodo in nodos)
            {
                switch (nodo.NodeType)
                {
                    case HtmlNodeType.Element:
                        switch (nodo.Name.ToLower())
                        {
                            case "p":
                                textoEnriquecido.AppendLine(); // Nueva línea para los párrafos
                                ProcesarNodosHtml(nodo.ChildNodes, textoEnriquecido);
                                textoEnriquecido.AppendLine(); // Nueva línea después del párrafo
                                break;
                            case "ul":
                                ProcesarListas(nodo, textoEnriquecido, "• "); // Viñetas para listas no numeradas
                                break;
                            case "ol":
                                ProcesarListas(nodo, textoEnriquecido, "{0}. "); // Números para listas numeradas
                                break;
                            case "img":
                                textoEnriquecido.Append("[Imagen]"); // Texto representativo para una imagen
                                break;
                            case "b":
                            case "strong":
                                textoEnriquecido.Append("<b>"); // Marca de inicio de texto en negrita
                                ProcesarNodosHtml(nodo.ChildNodes, textoEnriquecido);
                                textoEnriquecido.Append("</b>"); // Marca de fin de texto en negrita
                                break;
                            // Agrega más casos según tus necesidades, como para enlaces, etc.
                            default:
                                // En este caso, si el elemento no es uno de los casos especificados,
                                // simplemente se limpia la etiqueta y se conserva el texto encerrado por esa etiqueta.
                                textoEnriquecido.Append(System.Net.WebUtility.HtmlDecode(nodo.InnerHtml));
                                break;
                        }
                        break;
                    case HtmlNodeType.Text:
                        textoEnriquecido.Append(System.Net.WebUtility.HtmlDecode(nodo.InnerText)); // Decodificar entidades HTML y agregar texto normal
                        break;
                }
            }
        }

        private void ProcesarListas(HtmlNode nodoLista, StringBuilder textoEnriquecido, string prefijo)
        {
            int numeroElemento = 1;

            foreach (HtmlNode nodoItem in nodoLista.ChildNodes)
            {
                if (nodoItem.Name.ToLower() == "li")
                {
                    textoEnriquecido.Append(numeroElemento + ". ");
                    ProcesarNodosHtml(nodoItem.ChildNodes, textoEnriquecido);
                    textoEnriquecido.AppendLine();
                    numeroElemento++;
                }
            }
        }
    }
}