﻿using sacot.BLL.ClientsBLL;
using sacot.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sacot.Presentation.Clients
{
    public partial class Portada : System.Web.UI.Page
    { 

        protected void Page_Load(object sender, EventArgs e)
        {
            // Reiniciar el mensaje de error
            Lberror.Visible = false;
            if (!IsPostBack)
            {
                if (Session["IDUser"] != null)
                {
                    if (Request.QueryString["plantilla"] == null)
                    {
                        // redirecciona a plantillas
                        Response.Redirect("Plantillas.aspx");
                    } 
                }
                else
                {
                    Response.Redirect("../Common/Login.aspx");
                } 
                
            }
        }

        protected void BtnSiguiente_Click(object sender, EventArgs e)
        {
            // Reiniciar el mensaje de error
            Lberror.Visible = false;
            int plantillaId = Convert.ToInt32(Request.QueryString["plantilla"]);

            if (string.IsNullOrEmpty(TxbTitulo.Text) || string.IsNullOrEmpty(TxbCodigo.Text) ||
                string.IsNullOrEmpty(TxbElaboro.Text) || string.IsNullOrEmpty(TxbFechaElaboracion.Text) ||
                string.IsNullOrEmpty(TxbFechaRevision.Text) || string.IsNullOrEmpty(TxbVersion.Text) ||
                string.IsNullOrEmpty(TxbNomEmpresa.Text))
            {
                MostrarError("Todos los campos son obligatorios.");
                return;
            }

            // Verificar si se ha seleccionado un archivo
            if (!FileUploadLogo.HasFile)
            {
                MostrarError("Debe seleccionar un archivo de logo.");
                return;
            }

            // Verificar si el archivo es PNG 
            string extension = Path.GetExtension(FileUploadLogo.FileName);
            if (extension != ".png")
            {
                MostrarError("El archivo de logo debe ser formato PNG.");
                return;
            }

            // Verificar la resolución del archivo de imagen
            using (System.Drawing.Image img = System.Drawing.Image.FromStream(FileUploadLogo.PostedFile.InputStream))
            {
                if (img.Width < 150 || img.Height < 150 || img.Width > 300 || img.Height > 300)
                {
                    MostrarError("La resolución de la imagen debe ser entre 150px y 300px en ambas dimensiones.");
                    return;
                }
            }

            // Obtener los datos del formulario
            string titulo = TxbTitulo.Text;
            string codigo = TxbCodigo.Text;
            string elaboro = TxbElaboro.Text;
            DateTime fechaElaboracion;
            DateTime fechaRevision;
            if (!DateTime.TryParse(TxbFechaElaboracion.Text, out fechaElaboracion) || !DateTime.TryParse(TxbFechaRevision.Text, out fechaRevision))
            {
                MostrarError("Las fechas no tienen un formato válido.");
                return;
            }

            if (fechaRevision < fechaElaboracion)
            {
                MostrarError("La fecha de revisión debe ser mayor o igual a la fecha de elaboración.");
                return;
            }

            string version = TxbVersion.Text;
            string NombreEmpresa = TxbNomEmpresa.Text;
            // Convertir la imagen a un arreglo de bytes
            byte[] logoBytes = FileUploadLogo.FileBytes;

            // Crear una instancia de DocumentoPortada y asignar los valores
            DocumentoPortada portada = new DocumentoPortada
            {
                NombreEmpresa = NombreEmpresa,
                Titulo = titulo,
                Codigo = codigo,
                Elaboro = elaboro,
                Version = version,
                FechaElaboracion = fechaElaboracion,
                FechaRevision = fechaRevision,
                LogoBase64 = Convert.ToBase64String(logoBytes) // Convertir los bytes del logo a una cadena Base64
            };
            // Llamar al método en la capa de lógica de negocio para insertar los datos de la portada
            int idPortada = PortadaBLL.InsertarDatosConLogo(portada);
            int idusuario = Convert.ToInt16(Session["IDUser"]);
            if (idPortada != -1)
            {

                // Llamar al método en la capa de lógica de negocio para insertar el documento con la portada y el ID de la plantilla
                int idDocumento = PortadaBLL.InsertarDocumentoConPortada(idPortada, plantillaId, titulo, idusuario);
                if (idDocumento != -1)
                {
                    Lberror.Visible = false;
                    // Redireccionar a la página EncabePie.aspx y enviar el ID del documento insertado como parámetro
                    Response.Redirect($"EncabePie.aspx?Documento={idDocumento}");
                }
                else
                {
                    // Mostrar mensaje de error
                    MostrarError("Error al insertar el documento, intente nuevamente.");
                }
            }
            else
            {
                // Mostrar mensaje de error
                MostrarError("Error al insertar los datos de la portada, intente nuevamente.");
            }
        }


        private void MostrarError(string mensaje)
        {
            Lberror.Visible = true;
            Lberror.Text = mensaje;
        }

        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Plantillas.aspx");
        }
    }
}