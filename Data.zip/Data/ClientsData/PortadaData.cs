﻿using sacot.Model;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class PortadaData
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public static int InsertarDatosConLogo(DocumentoPortada portada)
        {
            int insertedId = -1;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO DocumentoPortada (Logo,NombreEmpresa, Titulo, Codigo, Elaboro, FechaElaboracion, FechaRevision, Version) " +
                               "VALUES (@Logo, @NombreEmpresa, @Titulo, @Codigo, @Elaboro, @FechaElaboracion, @FechaRevision, @Version); " +
                               "SELECT SCOPE_IDENTITY();";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Logo", Convert.FromBase64String(portada.LogoBase64)); // Convertir la cadena Base64 de nuevo a un arreglo de bytes
                    command.Parameters.AddWithValue("@NombreEmpresa", portada.NombreEmpresa); 
                    command.Parameters.AddWithValue("@Titulo", portada.Titulo);
                    command.Parameters.AddWithValue("@Codigo", portada.Codigo);
                    command.Parameters.AddWithValue("@Elaboro", portada.Elaboro);
                    command.Parameters.AddWithValue("@FechaElaboracion", portada.FechaElaboracion);
                    command.Parameters.AddWithValue("@FechaRevision", portada.FechaRevision);
                    command.Parameters.AddWithValue("@Version", portada.Version);

                    try
                    {
                        connection.Open();
                        insertedId = Convert.ToInt32(command.ExecuteScalar());
                    }
                    catch (Exception ex)
                    {
                        // Manejar la excepción 
                        Console.WriteLine("Error al insertar los datos de la portada: " + ex.Message);
                    }
                }
            }
            return insertedId;
        }

        public static int InsertarDocumentoConPortada(int idPortada, int idPlantilla, string titulo, int idusuario)
        {
            int idDocumento = -1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Documentos (IDUsuario,IDPlantilla,Titulo, DocumentoPortadaID) " +
                               "VALUES (@IDusuario,@IDPlantilla,@Titulo, @DocumentoPortadaID);" +
                               "SELECT SCOPE_IDENTITY();";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DocumentoPortadaID", idPortada);
                    command.Parameters.AddWithValue("@IDPlantilla", idPlantilla);
                    command.Parameters.AddWithValue("@Titulo", titulo);
                    command.Parameters.AddWithValue("@IDusuario", idusuario);
                    try
                    {
                        connection.Open();
                        // Ejecutar la consulta y obtener el ID del documento insertado
                        object result = command.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            idDocumento = Convert.ToInt32(result);
                        }
                        else
                        {
                            // Si el resultado es nulo, indica un error en la inserción
                            throw new Exception("No se pudo obtener el ID del documento insertado.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Manejar la excepción 
                        Console.WriteLine("Error al insertar el documento con la portada: " + ex.Message);
                    }
                }
            }
            return idDocumento;
        }
    }
}