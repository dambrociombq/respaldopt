﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class PlantillasData
    {
        private string connectionString;

        public PlantillasData()
        {
            // Obtener la cadena de conexión del archivo web.config
            connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
        }

        public List<Plantillas> GetPlantillas()
        {
            List<Plantillas> plantillas = new List<Plantillas>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Plantillas";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Plantillas plantilla = new Plantillas();
                    plantilla.PlantillaID = Convert.ToInt32(reader["PlantillaID"]);
                    plantilla.Titulo = reader["Titulo"].ToString(); 
                    plantilla.PlantillaPortadaID = reader["PlantillaPortadaID"] != DBNull.Value ? Convert.ToInt32(reader["PlantillaPortadaID"]) : (int?)null;
                    plantilla.PlantillaPiePaginaID = reader["PlantillaPiePaginaID"] != DBNull.Value ? Convert.ToInt32(reader["PlantillaPiePaginaID"]) : (int?)null;
                    plantilla.PlantillaEncabezadoID = reader["PlantillaEncabezadoID"] != DBNull.Value ? Convert.ToInt32(reader["PlantillaEncabezadoID"]) : (int?)null;
                    plantilla.FechaCreacion = Convert.ToDateTime(reader["FechaCreacion"]);
                    plantilla.ImgPortadaPath = reader["ImgPortadaPath"].ToString();
                    // Aquí puedes cargar las referencias a otras tablas si es necesario

                    plantillas.Add(plantilla);
                }
                reader.Close();
            }

            return plantillas;
        }
        
    }
}