﻿using sacot.Model;
using sacot.Presentation.Clients;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class MidocumentoData
    {
        string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public List<Documento> ObtenerDocumentos(int iduser)
        {
            List<Documento> documentos = new List<Documento>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT d.IDDocumento, d.Titulo, dp.Logo FROM Documentos d INNER JOIN DocumentoPortada dp ON d.DocumentoPortadaID = dp.DocumentoPortadaID WHERE d.IDUsuario=@iduser";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@iduser", iduser);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Documento documento = new Documento
                    {
                        IDDocumento= Convert.ToInt16(reader["IDDocumento"].ToString()),
                        Titulo = reader["Titulo"].ToString(),
                        LogoBytes = (byte[])reader["Logo"]
                    };

                    documento.LogoUrl = ConvertImageToUrl(documento.LogoBytes);

                    documentos.Add(documento);
                }

                reader.Close();
            }

            return documentos;
        }

        private string ConvertImageToUrl(byte[] imageBytes)
        {
            // Convierte los bytes de la imagen a una URL base64 en formato PNG
            string base64String = Convert.ToBase64String(imageBytes);
            return "data:image/png;base64," + base64String;
        }
        public Documento ObtenerDocumentoPorId(int idDocumento)
        {
            Documento documento = null;

            // Crea la conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Abre la conexión
                connection.Open();

                // Crea la consulta SQL
                string query = "SELECT * FROM Documentos WHERE IDDocumento = @IDDocumento";

                // Crea el comando SQL
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agrega los parámetros
                    command.Parameters.AddWithValue("@IDDocumento", idDocumento);

                    // Ejecuta la consulta y obtiene el resultado
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Verifica si se encontró un registro
                        if (reader.Read())
                        {
                            // Crea un objeto Documento y asigna los valores
                            documento = new Documento
                            {
                                IDDocumento = Convert.ToInt32(reader["IDDocumento"]),
                                IDUsuario = Convert.ToInt32(reader["IDUsuario"]),
                                IDPlantilla = Convert.ToInt32(reader["IDPlantilla"]),
                                Titulo = reader["Titulo"].ToString(),
                                DocumentoPortadaID = Convert.ToInt32(reader["IDPlantilla"]),
                                DocumentoPiePaginaID = Convert.ToInt32(reader["IDPlantilla"]),
                                DocumentoEncabezadoID = Convert.ToInt32(reader["IDPlantilla"]),
                                AutorizacionID = Convert.ToInt32(reader["IDPlantilla"])
                            };
                        }
                    }
                }
            }

            return documento;
        }
    }
}