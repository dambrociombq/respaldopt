﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Configuration;
using sacot.Model;
using sacot.Presentation.Clients;

namespace sacot.Data.ClientsData
{
    public class GeneracionPDFData
    {

        private static string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public Documento BuscarDocumentoPorId(int idDocumento)
        {
            Documento documento = null;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Documentos WHERE IDDocumento = @IDDocumento";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@IDDocumento", idDocumento);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        documento = new Documento
                        {
                            IDDocumento = Convert.ToInt32(reader["IDDocumento"]),
                            IDUsuario = Convert.ToInt32(reader["IDUsuario"]),
                            IDPlantilla = Convert.ToInt32(reader["IDPlantilla"]),
                            Titulo = reader["Titulo"].ToString(),
                            DocumentoPortadaID = Convert.ToInt32(reader["DocumentoPortadaID"]),
                            DocumentoPiePaginaID = Convert.ToInt32(reader["DocumentoPiePaginaID"]),
                            DocumentoEncabezadoID = Convert.ToInt32(reader["DocumentoEncabezadoID"]),
                            AutorizacionID = Convert.ToInt32(reader["AutorizacionID"])
                        };
                    }
                }
            }
            return documento;
        }

        public DocumentoPortada BuscarDocumentoPortadaPorId(int idDocumentoPortada)
        {
            DocumentoPortada documentoPortada = null;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM DocumentoPortada WHERE DocumentoPortadaID = @DocumentoPortadaID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@DocumentoPortadaID", idDocumentoPortada);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        documentoPortada = new DocumentoPortada
                        {
                            DocumentoPortadaID = Convert.ToInt32(reader["DocumentoPortadaID"]),
                            Logo = (byte[])reader["Logo"],
                            NombreEmpresa= reader["NombreEmpresa"].ToString(),
                            Titulo = reader["Titulo"].ToString(),
                            Codigo = reader["Codigo"].ToString(),
                            Elaboro = reader["Elaboro"].ToString(),
                            FechaElaboracion = Convert.ToDateTime(reader["FechaElaboracion"]),
                            FechaRevision = Convert.ToDateTime(reader["FechaRevision"]),
                            Version = reader["Version"].ToString()
                        };
                    }
                }
            }
            return documentoPortada;
        }

        public DocumentoEncabezado BuscarDocumentoEncabezadoPorId(int idDocumentoEncabezado)
        {
            DocumentoEncabezado documentoEncabezado = null;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM DocumentoEncabezado WHERE DocumentoEncabezadoID = @DocumentoEncabezadoID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@DocumentoEncabezadoID", idDocumentoEncabezado);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        documentoEncabezado = new DocumentoEncabezado
                        {
                            DocumentoEncabezadoID = Convert.ToInt32(reader["DocumentoEncabezadoID"]),
                            EncabezadoArea = reader["EncabezadoArea"].ToString()
                        };
                    }
                }
            }
            return documentoEncabezado;
        }

        public DocumentoPiePagina BuscarDocumentoPiePaginaPorId(int idDocumentoPiePagina)
        {
            DocumentoPiePagina documentoPiePagina = null;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM DocumentoPiePagina WHERE DocumentoPiePaginaID = @DocumentoPiePaginaID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@DocumentoPiePaginaID", idDocumentoPiePagina);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        documentoPiePagina = new DocumentoPiePagina
                        {
                            DocumentoPiePaginaID = Convert.ToInt32(reader["DocumentoPiePaginaID"]),
                            MostrarLogo = Convert.ToBoolean(reader["MostrarLogo"]),
                            MostrarNombreEmpresa = Convert.ToBoolean(reader["MostrarNombreEmpresa"]),
                            ContabilizarPaginas = Convert.ToBoolean(reader["ContabilizarPaginas"])
                        };
                    }
                }
            }
            return documentoPiePagina;
        }

        public Autorizaciones BuscarAutorizacionPorId(int idAutorizacion)
        {
            Autorizaciones autorizaciones = null;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Autorizaciones WHERE IDAutorizacion = @IDAutorizacion";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@IDAutorizacion", idAutorizacion);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        autorizaciones = new Autorizaciones
                        {
                            idAutorizaciones = reader["IDAutorizacion"].ToString(), // Corregir el nombre de la propiedad y convertir a string
                            NombreReviso = reader["NombreReviso"].ToString(),
                            PuestoReviso = reader["PuestoReviso"].ToString(),
                            NombreElaboro = reader["NombreElaboro"].ToString(),
                            PuestoElaboro = reader["PuestoElaboro"].ToString(),
                            NombreAutorizo = reader["NombreAutorizo"].ToString(),
                            PuestoAutorizo = reader["PuestoAutorizo"].ToString()
                        };
                    }
                }
            }
            return autorizaciones;
        }
        public List<HistorialCambioDocumento> ObtenerHistorialCambiosDocumentoPorId(int DocumentoID)
        {
            List<HistorialCambioDocumento> cambios = new List<HistorialCambioDocumento>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM HistorialCambiosDocumentos WHERE DocumentoID = @DocumentoID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@DocumentoID", DocumentoID);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        HistorialCambioDocumento cambio = new HistorialCambioDocumento
                        {
                            CambioID = Convert.ToInt32(reader["CambioID"]),
                            DocumentoID = Convert.ToInt32(reader["DocumentoID"]),
                            Fecha = Convert.ToDateTime(reader["Fecha"]),
                            DescripcionParrafo = reader["DescripcionParrafo"].ToString(),
                            RefParrafo = reader["RefParrafo"].ToString(),
                            RefPagina = reader["RefPagina"].ToString()
                        };
                        cambios.Add(cambio);
                    }
                }
            }

            return cambios;
        }

        public List<DocumentoTema> ObtenerDocumentoTemaPorId(int idDocumento)
        {
            List<DocumentoTema> temas = new List<DocumentoTema>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM DocumentoTemas WHERE DocumentoID = @idDocumento";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@idDocumento", idDocumento);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        DocumentoTema tema = new DocumentoTema
                        {
                            DocumentoTemaID = Convert.ToInt32(reader["DocumentoTemaID"]),
                            DocumentoID = Convert.ToInt32(reader["DocumentoID"]),
                            Tema = reader["Tema"].ToString(),
                            ContenidoTema = reader["ContenidoTema"].ToString()
                        };
                        temas.Add(tema);
                    }
                }
            }

            return temas;
        }
        public List<DocumentoSubtema> ObtenerDocumentoSubtemaPorId(int documentotemaID)
        {
            List<DocumentoSubtema> subtemas = new List<DocumentoSubtema>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM DocumentoSubtemas WHERE DocumentoTemaID = @documentotemaID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@documentotemaID", documentotemaID);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        DocumentoSubtema subtema = new DocumentoSubtema
                        {
                            DocumentoSubtemaID = Convert.ToInt32(reader["DocumentoSubtemaID"]),
                            DocumentoTemaID = Convert.ToInt32(reader["DocumentoTemaID"]),
                            Subtema = reader["Subtema"].ToString(),
                            ContenidoSubtema = reader["ContenidoSubtema"].ToString()
                        };
                        subtemas.Add(subtema);
                    }
                }
            }

            return subtemas;
        }
        public InformacionDocumento ObtenerInformacionDocumentoPorId(int DocumentoID)
        {
            InformacionDocumento informacion = null;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM InformacionDocumento WHERE DocumentoID = @DocumentoID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@DocumentoID", DocumentoID);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        informacion = new InformacionDocumento
                        {
                            IDInformacionDocumento = Convert.ToInt32(reader["IDInformacionDocumento"]),
                            DocumentoID = Convert.ToInt32(reader["DocumentoID"]),
                            AlineacionLogoVertical = reader["AlineacionLogoVertical"].ToString(),
                            AlineacionLogoHorizontal = reader["AlineacionLogoHorizontal"].ToString(), 
                            AlineacionInformacionPortadaVertical = reader["AlineacionInformacionPortadaVertical"].ToString(),
                            AlineacionInformacionPortadaHorizontal = reader["AlineacionInformacionPortadaHorizontal"].ToString(),
                            ColorTextoPortada = reader["ColorTextoPortada"].ToString(),
                            AlineacionEncabezado = reader["AlineacionEncabezado"].ToString(),
                            ColorTextoEncabezado = reader["ColorTextoEncabezado"].ToString(),
                            AlineacionPiePagina = reader["AlineacionPiePagina"].ToString(),
                            ColorTextoPiePagina = reader["ColorTextoPiePagina"].ToString(),
                            AlineacionTitulos = reader["AlineacionTitulos"].ToString(),
                            ColorTextoTitulos = reader["ColorTextoTitulos"].ToString()
                        };
                    }
                }
            }

            return informacion;
        }
        public void ActualizarArchivoPDF(int idDocumento, byte[] archivoPDF)
        {
            string queryString = "UPDATE Documentos SET ArchivoPDF = @ArchivoPDF WHERE IDDocumento = @IDDocumento";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Parameters.AddWithValue("@ArchivoPDF", archivoPDF);
                command.Parameters.AddWithValue("@IDDocumento", idDocumento);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}