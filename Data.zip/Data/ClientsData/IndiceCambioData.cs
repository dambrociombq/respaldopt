﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class IndiceCambioData
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public void InsertarCambio(int documentoID, DateTime fecha, string descripcionParrafo, string refParrafo, string refPagina)
        {
            string query = "INSERT INTO HistorialCambiosDocumentos (DocumentoID, Fecha, DescripcionParrafo, RefParrafo, RefPagina) " +
                           "VALUES (@DocumentoID, @Fecha, @DescripcionParrafo, @RefParrafo, @RefPagina)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@DocumentoID", documentoID);
                command.Parameters.AddWithValue("@Fecha", fecha);
                command.Parameters.AddWithValue("@DescripcionParrafo", descripcionParrafo);
                command.Parameters.AddWithValue("@RefParrafo", refParrafo);
                command.Parameters.AddWithValue("@RefPagina", refPagina);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}