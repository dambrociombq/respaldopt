﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class InformacionDocumentoData
    {

        private static string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public void InsertarInformacionDocumento(InformacionDocumento informacionDocumento)
        {
            string query = @"INSERT INTO InformacionDocumento (DocumentoID, AlineacionLogoVertical, AlineacionLogoHorizontal, AlineacionInformacionPortadaVertical, AlineacionInformacionPortadaHorizontal, ColorTextoPortada, AlineacionEncabezado, ColorTextoEncabezado, AlineacionPiePagina, ColorTextoPiePagina, AlineacionTitulos, ColorTextoTitulos)
                     VALUES (@DocumentoID, @AlineacionLogoVertical, @AlineacionLogoHorizontal, @AlineacionInformacionPortadaVertical, @AlineacionInformacionPortadaHorizontal, @ColorTextoPortada, @AlineacionEncabezado, @ColorTextoEncabezado, @AlineacionPiePagina, @ColorTextoPiePagina, @AlineacionTitulos, @ColorTextoTitulos)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DocumentoID", informacionDocumento.DocumentoID);
                    command.Parameters.AddWithValue("@AlineacionLogoVertical", informacionDocumento.AlineacionLogoVertical);
                    command.Parameters.AddWithValue("@AlineacionLogoHorizontal", informacionDocumento.AlineacionLogoHorizontal);
                    command.Parameters.AddWithValue("@AlineacionInformacionPortadaVertical", informacionDocumento.AlineacionInformacionPortadaVertical);
                    command.Parameters.AddWithValue("@AlineacionInformacionPortadaHorizontal", informacionDocumento.AlineacionInformacionPortadaHorizontal);
                    command.Parameters.AddWithValue("@ColorTextoPortada", informacionDocumento.ColorTextoPortada);
                    command.Parameters.AddWithValue("@AlineacionEncabezado", informacionDocumento.AlineacionEncabezado);
                    command.Parameters.AddWithValue("@ColorTextoEncabezado", informacionDocumento.ColorTextoEncabezado);
                    command.Parameters.AddWithValue("@AlineacionPiePagina", informacionDocumento.AlineacionPiePagina);
                    command.Parameters.AddWithValue("@ColorTextoPiePagina", informacionDocumento.ColorTextoPiePagina);
                    command.Parameters.AddWithValue("@AlineacionTitulos", informacionDocumento.AlineacionTitulos);
                    command.Parameters.AddWithValue("@ColorTextoTitulos", informacionDocumento.ColorTextoTitulos);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}