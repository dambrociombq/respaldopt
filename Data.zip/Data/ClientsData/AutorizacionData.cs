﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class AutorizacionData
    {
        // Método para insertar datos de autorización en la base de datos
        public int InsertarDatos(Autorizaciones autorizacion)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Autorizaciones (NombreReviso, PuestoReviso, NombreElaboro, PuestoElaboro, NombreAutorizo, PuestoAutorizo) " +
                               "VALUES (@nombreReviso, @puestoReviso, @nombreElaboro, @puestoElaboro, @nombreAutorizo, @puestoAutorizo); SELECT SCOPE_IDENTITY();";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@nombreReviso", autorizacion.NombreReviso);
                    command.Parameters.AddWithValue("@puestoReviso", autorizacion.PuestoReviso);
                    command.Parameters.AddWithValue("@nombreElaboro", autorizacion.NombreElaboro);
                    command.Parameters.AddWithValue("@puestoElaboro", autorizacion.PuestoElaboro);
                    command.Parameters.AddWithValue("@nombreAutorizo", autorizacion.NombreAutorizo);
                    command.Parameters.AddWithValue("@puestoAutorizo", autorizacion.PuestoAutorizo);
                    connection.Open();
                    int id = Convert.ToInt32(command.ExecuteScalar());
                    return id;
                }
            }
        }

        // Método para editar el documento con los datos de autorización
        public bool EditarDocAutorizo(int idDocumento, int idAutorizaciones)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Documentos SET AutorizacionID = @idAutorizaciones WHERE IDDocumento = @idDocumento";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idAutorizaciones", idAutorizaciones);
                    command.Parameters.AddWithValue("@idDocumento", idDocumento);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }
    }
}