﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class VistaPreliMisDocData
    {
        public static byte[] ObtenerPDFBytes(int iddocumento)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
            byte[] pdfBytes = null;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ArchivoPDF FROM Documentos WHERE IDDocumento = @iddocumento";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@iddocumento", iddocumento);

                try
                {
                    connection.Open();
                    pdfBytes = (byte[])command.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción
                }
            }

            return pdfBytes;
        }
    }
}