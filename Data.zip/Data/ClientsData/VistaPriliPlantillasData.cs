﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class VistaPriliPlantillasData
    {
        public static string ObtenerPDFPath(int plantillaId)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
            string pdfPath = "";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT PdfPath FROM Plantillas WHERE PlantillaId = @PlantillaId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlantillaId", plantillaId);

                try
                {
                    connection.Open();
                    pdfPath = (string)command.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    // Manejar la excepción
                }
            }

            return pdfPath;
        }
    }
}