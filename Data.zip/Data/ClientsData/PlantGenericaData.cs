﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class PlantGenericaData
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public List<PlantillaTemas> ObtenerTemasPorIdPlantilla(int idPlantilla)
        {
            List<PlantillaTemas> temas = new List<PlantillaTemas>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT PlantillaTemaID, Tema, ContenidoTema FROM PlantillaTemas WHERE PlantillaID = @idPlantilla";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@idPlantilla", idPlantilla);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    PlantillaTemas tema = new PlantillaTemas();
                    tema.PlantillaTemaID = Convert.ToInt32(reader["PlantillaTemaID"]);
                    tema.Tema = reader["Tema"].ToString();
                    tema.ContenidoTema = reader["ContenidoTema"].ToString();
                    temas.Add(tema);
                }
                connection.Close();
            }

            return temas;
        }

        public List<PlantillaSubtemas> ObtenerSubtemasPorIdTema(int idPlantillaTema)
        {
            List<PlantillaSubtemas> subtemas = new List<PlantillaSubtemas>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT PlantillaSubtemaID, Subtema, ContenidoSubtema FROM PlantillaSubtemas WHERE PlantillaTemaID = @idPlantillaTema";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@idPlantillaTema", idPlantillaTema);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    PlantillaSubtemas subtema = new PlantillaSubtemas();
                    subtema.PlantillaSubtemaID = Convert.ToInt32(reader["PlantillaSubtemaID"]);
                    subtema.Subtema = reader["Subtema"].ToString();
                    subtema.ContenidoSubtema = reader["ContenidoSubtema"].ToString();
                    subtemas.Add(subtema);
                }
                connection.Close();
            }
            return subtemas;
        }
        public void InsertarDocumentoSubtema(DocumentoSubtema documentoSubtema)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO DocumentoSubtemas (DocumentoTemaID, Subtema, ContenidoSubtema) " +
                               "VALUES (@DocumentoTemaID, @Subtema, @ContenidoSubtema)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@DocumentoTemaID", documentoSubtema.DocumentoTemaID);
                command.Parameters.AddWithValue("@Subtema", documentoSubtema.Subtema);
                command.Parameters.AddWithValue("@ContenidoSubtema", documentoSubtema.ContenidoSubtema);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public int InsertarDocumentoTema(DocumentoTema documentoTema)
        {
            int documentoTemaID = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO DocumentoTemas (DocumentoID, Tema, ContenidoTema) " +
                               "VALUES (@DocumentoID, @Tema, @ContenidoTema); SELECT SCOPE_IDENTITY();";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@DocumentoID", documentoTema.DocumentoID);
                command.Parameters.AddWithValue("@Tema", documentoTema.Tema);
                command.Parameters.AddWithValue("@ContenidoTema", documentoTema.ContenidoTema);

                connection.Open();
                documentoTemaID = Convert.ToInt32(command.ExecuteScalar());

            }
            return documentoTemaID;
        }
    }
}