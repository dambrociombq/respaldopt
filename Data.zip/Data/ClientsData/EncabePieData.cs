﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class EncabePieData
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        // Método para insertar un encabezado en la base de datos
        public int InsertarEncabezado(DocumentoEncabezado encabezado)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO DocumentoEncabezado (EncabezadoArea) VALUES (@EncabezadoArea); SELECT SCOPE_IDENTITY();";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@EncabezadoArea", encabezado.EncabezadoArea);

                connection.Open();
                int idEncabezado = Convert.ToInt32(command.ExecuteScalar());
                connection.Close();

                return idEncabezado;
            }
        }

        // Método para insertar un pie de página en la base de datos
        public int InsertarPiePagina(DocumentoPiePagina piePagina)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO DocumentoPiePagina (MostrarLogo, MostrarNombreEmpresa, ContabilizarPaginas) VALUES (@MostrarLogo, @MostrarNombreEmpresa, @ContabilizarPaginas); SELECT SCOPE_IDENTITY();";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@MostrarLogo", piePagina.MostrarLogo);
                command.Parameters.AddWithValue("@MostrarNombreEmpresa", piePagina.MostrarNombreEmpresa);
                command.Parameters.AddWithValue("@ContabilizarPaginas", piePagina.ContabilizarPaginas);

                connection.Open();
                int idPiePagina = Convert.ToInt32(command.ExecuteScalar());
                connection.Close();

                return idPiePagina;
            }
        }

        // Método para editar un documento con los datos del encabezado y pie de página
        public bool EditarDocumento(int idDocumento, int idEncabezado, int idPiePagina)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Documentos SET DocumentoEncabezadoID = @IDEncabezado, DocumentoPiePaginaID = @IDPiePagina WHERE IDDocumento = @IDDocumento;";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IDEncabezado", idEncabezado);
                command.Parameters.AddWithValue("@IDPiePagina", idPiePagina);
                command.Parameters.AddWithValue("@IDDocumento", idDocumento);

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                return rowsAffected > 0;
            }
        }
    }
}