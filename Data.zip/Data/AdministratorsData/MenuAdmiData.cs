﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.AdministratorsData
{
    public class MenuAdmiData
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public Usuarios ObtenerUsuarioYRole(int idUsuario)
        {
            Usuarios usuario = null;

            // Consulta SQL para obtener el nombre de usuario y el nombre del rol
            string query = "SELECT u.NombreUsuario, r.NombreRole " +
                           "FROM Usuarios u " +
                           "INNER JOIN Roles r ON u.IDRole = r.IDRole " +
                           "WHERE u.IDUsuario = @IDUsuario";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@IDUsuario", idUsuario);
                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        usuario = new Usuarios();
                        usuario.NombreUsuario = reader["NombreUsuario"].ToString();
                        usuario.NombreRole = reader["NombreRole"].ToString();
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                // Manejo de excepciones
                Console.WriteLine("Error al obtener el usuario y rol: " + ex.Message);
                throw; // Re-lanza la excepción para que sea manejada en la capa de lógica de negocios
            }

            return usuario;
        }
    }
}