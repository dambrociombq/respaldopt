﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace sacot.Data.AdministratorsData
{
    public class ListaUserData
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public List<Usuarios> ObtenerUsuarios()
        {
            List<Usuarios> usuarios = new List<Usuarios>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT u.IDUsuario, u.NombreUsuario, u.Contrasena, u.CorreoElectronico,
                                u.Nombre, u.Apellido, r.NombreRole AS NombreRol, u.Estado
                         FROM Usuarios u
                         INNER JOIN Roles r ON u.IDRole = r.IDRole";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Usuarios usuario = new Usuarios
                            {
                                IDUsuario = Convert.ToInt32(reader["IDUsuario"]),
                                NombreUsuario = reader["NombreUsuario"].ToString(),
                                Contrasena = reader["Contrasena"].ToString(),
                                CorreoElectronico = reader["CorreoElectronico"].ToString(),
                                Nombre = reader["Nombre"].ToString(),
                                Apellido = reader["Apellido"].ToString(),
                                NombreRole = reader["NombreRol"].ToString(),  
                                Estado = reader["Estado"].ToString()
                            };
                            usuarios.Add(usuario);
                        }
                    }
                }
            }

            return usuarios;
        }
    }
}