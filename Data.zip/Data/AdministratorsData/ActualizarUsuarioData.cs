﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

namespace sacot.Data.AdministratorsData
{
    public class ActualizarUsuarioData
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;

        public Usuarios ObtenerUsuarioPorID(int IDUsuario)
        {
            Usuarios usuario = null;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT IDUsuario, NombreUsuario, CorreoElectronico,
                                Nombre, Apellido, NombreRole AS Rol, Estado
                                FROM Usuarios u
                                INNER JOIN Roles r ON u.IDRole = r.IDRole
                                WHERE IDUsuario = @IDUsuario";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@IDUsuario", IDUsuario);
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            usuario = new Usuarios
                            {
                                IDUsuario = Convert.ToInt32(reader["IDUsuario"]),
                                NombreUsuario = reader["NombreUsuario"].ToString(),
                                CorreoElectronico = reader["CorreoElectronico"].ToString(),
                                Nombre = reader["Nombre"].ToString(),
                                Apellido = reader["Apellido"].ToString(),
                                NombreRole = reader["Rol"].ToString(),
                                Estado = reader["Estado"].ToString()
                            };
                        }
                    }
                }
            }

            return usuario;
        }

        public void ActualizarUsuario(Usuarios usuario)
        {
            // Obtener el ID del rol por su nombre
            int idRol = ObtenerIDRolPorNombre(usuario.NombreRole);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Usuarios
                                SET NombreUsuario = @NombreUsuario,
                                    CorreoElectronico = @CorreoElectronico, 
                                    Nombre = @Nombre, 
                                    Apellido = @Apellido, 
                                    IDRole = @IDRole, 
                                    Estado = @Estado
                                WHERE IDUsuario = @IDUsuario";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@NombreUsuario", usuario.NombreUsuario); 
                    command.Parameters.AddWithValue("@CorreoElectronico", usuario.CorreoElectronico);
                    command.Parameters.AddWithValue("@Nombre", usuario.Nombre);
                    command.Parameters.AddWithValue("@Apellido", usuario.Apellido);
                    command.Parameters.AddWithValue("@IDRole", idRol);
                    command.Parameters.AddWithValue("@Estado", usuario.Estado);
                    command.Parameters.AddWithValue("@IDUsuario", usuario.IDUsuario);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
        public bool BuscarExistenciaUsuario(string nombreUsuario, int idusuario)
        {
            // Query SQL para contar los usuarios con el nombre de usuario especificado
            string query = "SELECT COUNT(*) FROM Usuarios WHERE NombreUsuario = @NombreUsuario AND IDUsuario != @IDUsuario";

            // Variable para almacenar el resultado de la consulta
            int count = 0;

            // Establecer la conexión a la base de datos y ejecutar el comando
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Establecer los parámetros del comando
                    command.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                    command.Parameters.AddWithValue("@IDUsuario", idusuario);

                    try
                    {
                        // Abrir la conexión y ejecutar el comando
                        connection.Open();
                        count = (int)command.ExecuteScalar(); // Obtener el resultado de la consulta
                    }
                    catch (SqlException ex)
                    {
                        // Manejar la excepción (log, notificar, etc.)
                        // Por simplicidad, simplemente lanzamos la excepción nuevamente
                        throw ex;
                    }
                }
            }
            // Si el conteo es mayor que cero, significa que el usuario ya existe
            return count > 0;
        }

        public bool BuscarExistenciaCorreo(string correo, int idusuario)
        {
            // Query SQL para contar los usuarios con el correo electrónico especificado
            string query = "SELECT COUNT(*) FROM Usuarios WHERE CorreoElectronico = @CorreoElectronico AND IDUsuario != @IDUsuario";

            // Variable para almacenar el resultado de la consulta
            int count = 0;

            // Establecer la conexión a la base de datos y ejecutar el comando
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Establecer los parámetros del comando
                    command.Parameters.AddWithValue("@CorreoElectronico", correo);
                    command.Parameters.AddWithValue("@IDUsuario", idusuario);

                    try
                    {
                        // Abrir la conexión y ejecutar el comando
                        connection.Open();
                        count = (int)command.ExecuteScalar(); // Obtener el resultado de la consulta
                    }
                    catch (SqlException ex)
                    {
                        // Manejar la excepción (log, notificar, etc.)
                        // Por simplicidad, simplemente lanzamos la excepción nuevamente
                        throw ex;
                    }
                }
            }
            // Si el conteo es mayor que cero, significa que el correo electrónico ya existe
            return count > 0;
        }
        public int ObtenerIDRolPorNombre(string nombreRol)
        {
            int idRol =0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT IDRole FROM Roles WHERE NombreRole = @NombreRole";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@NombreRole", nombreRol); 
                    connection.Open();

                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        idRol = (int)result;
                    }
                }
            }

            return idRol;
        }
    }
}
