﻿using System.Data.SqlClient;
using System.Configuration;
using sacot.Model;

namespace sacot.Data.AdministratorsData
{
    public class RegUsuarioData
    {
        private string connectionString;

        public RegUsuarioData()
        {
            // Obtener la cadena de conexión del archivo web.config
            connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
        }

        // Método para insertar un nuevo usuario en la base de datos
        public void InsertarUsuario(Usuarios usuario)
        {
            // Cadena SQL para la inserción de un nuevo usuario
            string query = "INSERT INTO Usuarios ( NombreUsuario, Contrasena, CorreoElectronico, Nombre, Apellido, IDRole) " +
                           "VALUES (@NombreUsuario, @Contrasena, @CorreoElectronico, @Nombre, @Apellido, @IDRole)";

            // Crear una nueva conexión utilizando la cadena de conexión
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Abrir la conexión
                connection.Open();

                // Crear un nuevo comando utilizando la cadena SQL y la conexión
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agregar parámetros al comando para evitar inyección SQL y asegurar una consulta segura
                    command.Parameters.AddWithValue("@NombreUsuario", usuario.NombreUsuario);
                    command.Parameters.AddWithValue("@Contrasena", usuario.Contrasena);
                    command.Parameters.AddWithValue("@CorreoElectronico", usuario.CorreoElectronico);
                    command.Parameters.AddWithValue("@Nombre", usuario.Nombre);
                    command.Parameters.AddWithValue("@Apellido", usuario.Apellido);
                    command.Parameters.AddWithValue("@IDRole", usuario.IDRole);

                    // Ejecutar el comando (realizar la inserción)
                    command.ExecuteNonQuery();
                }
            }
        }

        // Método para verificar si un usuario ya existe en la base de datos
        public bool ExisteUsuario(string nombreUsuario, string correo)
        {
            // Query SQL para contar los usuarios con el nombre de usuario o correo electrónico especificado
            string query = "SELECT COUNT(*) FROM Usuarios WHERE NombreUsuario = @NombreUsuario OR CorreoElectronico = @CorreoElectronico";

            // Variable para almacenar el resultado de la consulta
            int count = 0;

            // Establecer la conexión a la base de datos y ejecutar el comando
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Establecer los parámetros del comando
                    command.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                    command.Parameters.AddWithValue("@CorreoElectronico", correo);

                    try
                    {
                        // Abrir la conexión y ejecutar el comando
                        connection.Open();
                        count = (int)command.ExecuteScalar(); // Obtener el resultado de la consulta
                    }
                    catch (SqlException ex)
                    {
                        // Manejar la excepción (log, notificar, etc.)
                        // Por simplicidad, simplemente lanzamos la excepción nuevamente
                        throw ex;
                    }
                }
            }
            // Si el conteo es mayor que cero, significa que el usuario ya existe
            return count > 0;
        }
         
    }
}
