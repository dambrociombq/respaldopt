﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.Common
{
    public class LoginData
    {
        private string connectionString;

        public LoginData()
        {
            // Obtener la cadena de conexión del archivo web.config
            connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
        }

        public Usuarios ObtenerUsuarioPorEmail(string email, string contrasena)
        {
            Usuarios usuario = null;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT IDUsuario, NombreUsuario, Contrasena, CorreoElectronico, IDRole, Estado FROM Usuarios WHERE CorreoElectronico = @Email AND Contrasena = @Contrasena";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Contrasena", contrasena); // Agregar el parámetro de la contraseña
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    usuario = new Usuarios
                    {
                        IDUsuario = Convert.ToInt32(reader["IDUsuario"]),
                        NombreUsuario = reader["NombreUsuario"].ToString(),
                        Contrasena = reader["Contrasena"].ToString(),
                        IDRole = Convert.ToInt32(reader["IDRole"]),
                        CorreoElectronico = reader["CorreoElectronico"].ToString(),
                        Estado= reader["Estado"].ToString()
                    };
                }
            }
            return usuario;
        }
    }
}