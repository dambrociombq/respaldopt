﻿using sacot.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace sacot.Data.ClientsData
{
    public class EditarUsuarioData
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
        public Usuarios ObtenerUsuarioPorID(int IDUsuario)
        {
            Usuarios usuario = null; 
            // Consulta SQL para obtener el usuario por su ID
            string query = "SELECT * FROM Usuarios WHERE IDUsuario = @IDUsuario";

            // Crear y abrir la conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IDUsuario", IDUsuario);

                try
                {
                    connection.Open();

                    // Ejecutar la consulta y leer el resultado
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        usuario = new Usuarios
                        {
                            IDUsuario = (int)reader["IDUsuario"],
                            NombreUsuario = reader["NombreUsuario"].ToString(),
                            Contrasena = reader["Contrasena"].ToString(),
                            CorreoElectronico = reader["CorreoElectronico"].ToString(),
                            Nombre = reader["Nombre"].ToString(),
                            Apellido = reader["Apellido"].ToString(),
                            IDRole = (int)reader["IDRole"],
                            Estado = reader["Estado"].ToString()
                        };
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    // Manejar excepciones
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
            return usuario;
        }

        // Método para actualizar la contraseña de un usuario
        public bool ActualizarContraseña(int IDUsuario, string nuevaContraseña)
        { 
            // Consulta SQL para actualizar la contraseña
            string query = "UPDATE Usuarios SET Contrasena = @NuevaContraseña WHERE IDUsuario = @IDUsuario";

            // Crear y abrir la conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IDUsuario", IDUsuario);
                command.Parameters.AddWithValue("@NuevaContraseña", nuevaContraseña);

                try
                {
                    connection.Open();

                    // Ejecutar la consulta
                    int rowsAffected = command.ExecuteNonQuery();

                    // Verificar si se actualizaron filas
                    if (rowsAffected > 0)
                        return true; // La contraseña se actualizó correctamente
                }
                catch (Exception ex)
                {
                    // Manejar excepciones
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
            return false; // La contraseña no se pudo actualizar
        }
    }
}